package product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import user.UserDTO;


public class ProductDAO{
	//여러번 사용하기 위해서 필드로 선언
	private Scanner scan; 
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	//드라이버 연결 메소드
	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn
			= DriverManager.getConnection(
					"jdbc:oracle:thin:@211.223.59.99:1521:xe","smart04", "0000");
//			System.out.println("db연결");
		}catch(Exception e) {
			System.out.println("db 연결 오류");
		}
	}
	
	
	//1.전체상품목록조회 & 출력 메소드
	public ArrayList<ProductDTO> product_list() {
		
		ArrayList<ProductDTO> list= new ArrayList<ProductDTO>();
		connect();
		String sql 
				= "SELECT * FROM tbL_java_product ORDER BY 1";
		
		try{
			 ps = conn.prepareStatement(sql);
			 rs = ps.executeQuery(); 
			 while(rs.next()) { 
				 ProductDTO dto = new ProductDTO();
				 dto.setNum(rs.getInt("num"));
				 dto.setName(rs.getString("name"));
				 dto.setCompany(rs.getString("company"));
				 dto.setPrice(rs.getInt("price"));
				 dto.setQty(rs.getInt("qty"));
				 list.add(dto);		
				 
			
			 }	
			
		}catch(Exception e) {
			System.out.println("상품목록조회 오류");
			System.out.println("원인: " + e.getMessage());
			
		}finally {
			
			disconnect();
		}
		return list;
		
	}
	
	
	//자원회수처리 메소드
	public void disconnect() {
			if(rs!=null) {try {rs.close();}catch (Exception e) {} }
			if(ps!=null) {try {ps.close();}catch (Exception e) {} }
			if(conn!=null) {try {conn.close();}catch (Exception e) {} }
		}
	
	//2-1.상품 검색 메소드: 이름으로 검색
	public ArrayList<ProductDTO> select_name(String name) {
		ArrayList<ProductDTO> list= new ArrayList<ProductDTO>();
		connect();
		
		String sql
		= "SELECT * "
		+ "FROM tbL_java_product "
		+ "WHERE name like ? "
		+ "ORDER BY 1";
		
	try {
		ps = conn.prepareStatement(sql);
		ps.setString(1, "%" +name+"%");
		rs = ps.executeQuery();
		while(rs.next()) {
			ProductDTO dto = new ProductDTO();
			dto.setNum(rs.getInt("num"));
			dto.setName(rs.getString("name"));
			dto.setCompany(rs.getString("company"));
			dto.setPrice(rs.getInt("price"));
			dto.setQty(rs.getInt("qty"));
			list.add(dto);
		
			
		}
	}catch(Exception e) {
		System.out.println("상품명 검색 오류");
		System.out.println("원인 : "+ e.getMessage());
	}finally {
		disconnect();
	}
	return list;	
		
		
	}
	
	//2-2.상품 검색 메소드: 출판사 검색
		public ArrayList<ProductDTO> select_company(String company) {
			ArrayList<ProductDTO> list= new ArrayList<ProductDTO>();
			
			connect();
			
			String sql
			= "SELECT * "
			+ "FROM tbL_java_product "
			+ "WHERE  company Like ?";
			
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, "%" +company +"%");
			rs = ps.executeQuery();
			while(rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				list.add(dto);
			
				
			}
		}catch(Exception e) {
			System.out.println("출판사 검색 오류");
			System.out.println("원인 : "+ e.getMessage());
		}finally {
			disconnect();
		}
		return list;	
		}	
		
	
	//3.상품 추가 메소드
	public ProductDTO insert(String name, String company, int price, int  qty) {
		
		ProductDTO dto = new ProductDTO();
		connect();
	
		try {
			
		 String sql
		 = "INSERT INTO tbL_java_product "
		 + "VALUES(num_seq.nextval, ? , ?, ?, ?)";
			
		 ps = conn.prepareStatement(sql);
		 //준비된 문장 ? 에 값을 담는다 
		 
		 
		ps.setString(1, name);
		ps.setString(2, company);
		ps.setInt(3, price);
		ps.setInt(4, qty);

		int count = ps.executeUpdate(); //업데이트된 데이터 행의 갯수 반환
		if(count > 0) {
			System.out.println("상품이 추가 되었습니다");
		}
		
		
		} catch (Exception e) {
			System.out.println("insert 오류");
		}finally {
			disconnect();
		}return dto;	
		
	}
	
	//4.상품 삭제 메소드 
	public ProductDTO delete(int num) {
		ProductDTO dto = new ProductDTO();
		connect();
		
		try {
			String sql
			="DELETE FROM tbL_java_product "
			+"WHERE num = ?";
			
			 ps = conn.prepareStatement(sql);
			 //준비된 문장 ? 에 값을 담는다 
			 
			 ps.setInt(1, num);
			 int count = ps.executeUpdate();
			 if(count > 0) {
					System.out.println("상품이 삭제되었습니다");
				}
				
			
		} catch (Exception e) {
			System.out.println("삭제처리 오류");
		}finally {
			disconnect();
		}return dto;	
	}
	
	//재고 조회 메소드
	public int check_stock(int num) {
		connect();
		int count_st= 0;
		
		String sql 
		="select qty "
		+"from tbL_java_product "
		+"where num = ? ";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			rs = ps.executeQuery(); 
			
			if(rs.next()) {
				count_st = (rs.getInt("qty"));
			}
			
		} catch (Exception e) {
			System.out.println("재고 조회 오류");
			System.out.println(e.getMessage());
		}finally {
			disconnect();
			
		}return count_st;	
		
	}
	
	//재고관리 메소드 : 상품 입고(입력값 : 상품 번호, 수량)
	public ProductDTO add_list(int qty, int num) {
		ProductDTO dto = null;
		connect();
			String sql1
			="UPDATE tbL_java_product "
			+"SET qty = qty + ? "
			+"WHERE num = ?";
			
			String sql2
			="SELECT * "
			+"FROM tbL_java_product "
			+"WHERE num = ?";
			
		try {
			ps = conn.prepareStatement(sql1);
			ps.setInt(1,qty);
			ps.setInt(2, num);
			ps.executeUpdate();
			
			ps = conn.prepareStatement(sql2);
			ps.setInt(1,num);
			rs= ps.executeQuery();
			 if(rs.next()) {
				dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty")); 
			 }
				
			
		} catch (Exception e) {
			System.out.println("상품 입고 오류");
			
		}finally {
			disconnect();
		}return dto;	
		
	}
	
	//재고관리 : 상품 출고
	public ProductDTO minus_list(int qty, int num) {
		ProductDTO dto = null;
		connect();
			String sql
			="UPDATE tbL_java_product "
			+"SET qty = qty - ? "
			+"WHERE num = ?";
			
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1,qty);
			ps.setInt(2, num);
			ps.executeUpdate();
			
			sql
			="SELECT * "
			+"FROM tbL_java_product "
			+"WHERE num = ?";
			
			ps = conn.prepareStatement(sql);
			ps.setInt(1,num);
			rs= ps.executeQuery();
			 if(rs.next()) {
				dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty")); 
			 }
				
			
		} catch (Exception e) {
			System.out.println("상품 출고 오류");
			
		}finally {
			disconnect();
		}return dto;	
		
	}
	
	//주문 금액 확인 메소드
	public int purchase(int num) {
		int purchase = 0;
		connect();
		
		String sql
		="select price "
		+"from tbL_java_product "
		+"where num = ?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			rs = ps.executeQuery(); 
			
			if(rs.next()) {
				purchase = (rs.getInt("price"));
			}
			
		} catch (Exception e) {
			System.out.println("주문 금액 오류");
		}finally {
			disconnect();
		}return purchase;	
		

	
	}
	
	
	//상품 주문& 상품 테이블 수량 변경

	public ProductDTO order_product(int num ,String id,  int qty) {

	ProductDTO dto = null;
	connect();
	
		//내 잔액 변경
		String sql1
		= "UPDATE tbl_java_user "
		+ "SET  money = money-((select price from tbl_java_product where num = ?)* ?) "          
		+ "WHERE id = ?" ;

		//상품 수량 변경
		 String sql2
		="UPDATE tbL_java_product "
		+"SET qty = qty - ? "
		+"WHERE num =?" ;
		
		//주문상품 확인
		 String sql3
		 ="SELECT num, name, price "
		 +"FROM tbL_java_product "
		 +"WHERE num =?" ;
		
		try {
			
		ps = conn.prepareStatement(sql1); 
		ps.setInt(1,num);
		ps.setInt(2,qty);
		ps.setString(3,id);
		
		ps.executeUpdate();

		ps = conn.prepareStatement(sql2); 
		ps.setInt(1,qty);
		ps.setInt(2,num);
		ps.executeUpdate();
		 
		ps = conn.prepareStatement(sql3);
		ps.setInt(1,num);
		rs = ps.executeQuery();
		if(rs.next()) {
			 dto = new ProductDTO(); //1. 정보를 담을 데이터 객체 생성
			 dto.setNum(rs.getInt("num"));
			 dto.setName(rs.getString("name"));
			 dto.setPrice(rs.getInt("price"));	 
			 
		 }
		
//		System.out.println("주문이 완료되었습니다.");
		
	} catch (Exception e) {
		System.out.println("상품 주문 오류");
		System.out.println(e.getMessage());
	}finally {
		disconnect();
	}
	return dto;
	
}//odrder_product
}


	
	
	

