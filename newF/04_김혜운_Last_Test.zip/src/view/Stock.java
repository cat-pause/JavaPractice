package view;

import java.util.Scanner;

import product.ProductDAO;
import product.ProductDTO;

public class Stock {

	Scanner scan;
	public Stock(Scanner scan) {
		this.scan = scan;
	}
	
	//상품 입고
	public void add_stock(int qty, int num) {
		ProductDAO dao = new ProductDAO();
		ProductDTO dto = dao.add_list(qty, num);
		
		System.out.println("\t[입고 확인]\t");
		System.out.printf("%-6s\t: %d\n",
				"상품번호:",dto.getNum());
		System.out.printf("%-6s\t: %s\n",
				"상품명:",dto.getName());
		System.out.printf("%-6s\t: %s\n",
				"회사명:",dto.getCompany());
		System.out.printf("%-6s\t: %d\n",
				"가격:",dto.getPrice());
		System.out.printf("%-6s\t: %d\n",
				"입고량:",qty);
		System.out.printf("%-6s\t: %d\n",
				"재고량:",dto.getQty());
		
		System.out.println();
		System.out.println("--------------------------------------[메뉴]---------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.admin.display();
			break;
		default:
			System.exit(0);
		}		
		
	}
		
			
	//상품 출고
	public void minus_stock(int qty, int num) {
		ProductDAO dao = new ProductDAO();
		ProductDTO dto = dao.minus_list(qty, num);
		
		System.out.println("\t[출고 확인]\t");
		System.out.printf("%-6s\t: %d\n",
				"상품번호:",dto.getNum());
		System.out.printf("%-6s\t: %s\n",
				"상품명:",dto.getName());
		System.out.printf("%-6s\t: %s\n",
				"회사명:",dto.getCompany());
		System.out.printf("%-6s\t: %d\n",
				"가격:",dto.getPrice());
		System.out.printf("%-6s\t: %d\n",
				"출고량:",qty);
		System.out.printf("%-6s\t: %d\n",
				"재고량:",dto.getQty());
		
		System.out.println();
		System.out.println("--------------------------------------[메뉴]---------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.admin.display();
			break;
		default:
			System.exit(0);
		}		
	}
}
