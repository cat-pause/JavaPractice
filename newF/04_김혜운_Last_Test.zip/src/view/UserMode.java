package view;

import java.util.ArrayList;
import java.util.Scanner;

import product.ProductDAO;
import product.ProductDTO;

public class UserMode {
	
		
	private Scanner scan;
	public UserMode(Scanner scan) {
		this.scan = scan;
	}
		
	public void display() {
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> list = dao.product_list();
		  
		System.out.println("\t\t\t\t[상품목록]");  
		System.out.println(
				"상품번호\t상품명\t\t\t\t제조사\t\t\t상품 가격\t 상품 수량(재고)");
		for(ProductDTO dto : list) {
			System.out.printf("%-3d\t\t", dto.getNum());
			System.out.printf("%-15s\t\t", dto.getName());
			System.out.printf("%-10s\t\t", dto.getCompany());
			System.out.printf("%7d\t\t", dto.getPrice());
			System.out.printf("%3d\t\t\n", dto.getQty());
							
		}
		System.out.println("=====================================================================================================\n");
		System.out.println("메뉴를 선택하세요");
		System.out.println("1.잔액 정보      2.상품 주문         3. 로그아웃");
		System.out.println("선택 : ");
		switch(scan.nextInt()) {
		case 1:
			System.out.println("=====================================[잔액 조회]=====================================================\n");
			System.out.println("1.잔액 조회   2. 잔액 추가");
			int menu = scan.nextInt();
			if(menu == 1) {
				System.out.println("아이디를 입력하세요");
				String id = scan.next();
				View.deposit.display_list(id);
				break;
			}else if(menu == 2) {
				System.out.println("아이디를 입력하세요");
				String id = scan.next();
				System.out.println("추가할 금액을 입력하세요");
				int money = scan.nextInt();
				View.deposit.display_add(money, id);
				break;
			}	
		case 2:
			System.out.println("=====================================[상품 주문]=====================================================\n");
			System.out.println("아이디를 입력하세요");
			String id = scan.next();
			System.out.println("주문 할 상품번호를 입력하세요");
			int num = scan.nextInt();
			System.out.println("주문 할 상품 수량을 입력하세요");
			int qty = scan.nextInt();
			View.order.display(num, id, qty);
				
		default:
			System.out.println("=====================================[로그 아웃]=====================================================\n");
			System.exit(3);
			
		
		}
		
	}

}
