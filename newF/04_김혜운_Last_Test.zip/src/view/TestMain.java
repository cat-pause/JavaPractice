package view;

import java.util.Scanner;

public class TestMain {
	public static void main(String[] args) {
		
		 Scanner scan= new Scanner(System.in);
		 View.login=  new Login(scan);
		 View.user = new UserMode(scan);
		 View.admin = new AdminMode(scan);
		 View.search = new ProductSearch(scan);
		 View.insert = new ProductInsert(scan);
		 View.delete =new ProductDelete(scan);
		 View.stock = new Stock(scan);
		 View.deposit = new Deposit(scan);
		 View.order = new Order(scan);
		 View.login.display();
	
		 scan.close();
	
	}	 
	
}
 