package view;

import java.util.Scanner;


import user.UserDAO;
import user.UserDTO;

public class Login {
	private Scanner scan;
	public Login(Scanner scan) {
		this.scan = scan;
	}
	
	public void display() { 
		
		UserDTO dto = null;
		do {
			
			System.out.println("아이디를 입력하세요");
			String id = scan.next();
			System.out.println("비밀번호를 입력하세요");
			String pw = scan.next();
			
			UserDAO dao = new UserDAO();
			dto = dao.login(id, pw);
			
			if(dto != null) { //가져온 값이 있다면
				
				if(dto.getAdmin().equals("Y")){
					System.out.println("로그인 완료, 관리자모드로 전환됩니다.");
					System.out.println(
							"=====================================================================================================\n");
					View.admin.display();
					
				}else if(dto.getAdmin().equals("N")) {
					System.out.println("로그인 되었습니다.");
				System.out.println(
						"=====================================================================================================\n");
					View.user.display();
				}
			}
				
		
		}while(dto == null ); //가져온 값이 없다면 반복
		
	}


	
	

}
	

