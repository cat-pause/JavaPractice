package view;


import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Scanner;

import product.ProductDAO;
import product.ProductDTO;

public class ProductInsert {

	Scanner scan;
	public ProductInsert(Scanner scan) {
		this.scan = scan;
	}
	
	public void display(String name, String company, int price, int  qty) {
		ProductDAO dao = new ProductDAO();
		ProductDTO dto = dao.insert(name, company, price, qty);
		
		System.out.println();
		System.out.println("--------------------------------------[메뉴]---------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.admin.display();
			break;
		default:
			System.exit(0);
		}		
					 
	}
		

}
