package view;

import java.util.Scanner;

public class LogOut {
	Scanner scan;
	public LogOut(Scanner scan) {
		this.scan = scan;
	}
	public void display() {
		
	}
}
