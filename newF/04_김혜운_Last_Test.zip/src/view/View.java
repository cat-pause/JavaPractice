package view;

import user.UserDTO;

public class View {
//화면구현
	static Login login;
	static UserMode user;
	static AdminMode admin;
	static ProductSearch search;
	static ProductInsert insert;
	static ProductDelete delete;
	static Stock stock;
	static LogOut logout;
	static Deposit deposit;
	static Order order;

}
