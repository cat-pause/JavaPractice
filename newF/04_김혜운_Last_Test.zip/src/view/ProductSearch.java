package view;

import java.util.ArrayList;
import java.util.Scanner;


import product.ProductDAO;
import product.ProductDTO;

public class ProductSearch {

	private Scanner scan;
	public ProductSearch(Scanner scan) {
		this.scan = scan;	
	}
	
	public void display_name(String name) {
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> list = dao.select_name(name);
		 
	
	System.out.println("\t\t[상품정보]");	
	
		if(list== null) {
			System.out.println("상품 정보 없음 ");
			
		}else {
			for (ProductDTO dto : list) {
				System.out.printf("%-3d\t\t", dto.getNum());
				System.out.printf("%-15s\t\t", dto.getName());
				System.out.printf("%-10s\t\t", dto.getCompany());
				System.out.printf("%7d\t\t\t", dto.getPrice());
				System.out.printf("%3d\t\t\n", dto.getQty());
			} 
			
		}
		System.out.println();
		System.out.println("--------------------------------------------[메뉴]----------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.admin.display();
			break;
			
		default:
			System.exit(0);
		}		
	}
	
	
	
	public void display_company(String company) {
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> list = dao.select_company(company);
		 
	
	System.out.println("\t\t[상품정보]");	 
	if(list== null) {
		System.out.println("상품 정보 없음 ");
	
	}else {
		for (ProductDTO dto : list) {
			System.out.printf("%-3d\t\t", dto.getNum());
			System.out.printf("%-15s\t\t", dto.getName());
			System.out.printf("%-10s\t\t", dto.getCompany());
			System.out.printf("%7d\t\t\t", dto.getPrice());
			System.out.printf("%3d\t\t\n", dto.getQty());
		} 
	
	}
		System.out.println();
		System.out.println("--------------------------------------------[메뉴]----------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.admin.display();
			break;
	
		default:
			System.exit(0);
		}		
	
	}
	
}
	
	

