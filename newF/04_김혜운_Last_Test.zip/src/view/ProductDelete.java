package view;

import java.util.ArrayList;
import java.util.Scanner;

import product.ProductDAO;
import product.ProductDTO;

public class ProductDelete {
	
	Scanner scan;
	public ProductDelete(Scanner scan) {
		this.scan = scan;
	}
	public void display(int num) {
		
		
		
		ProductDAO	dao = new ProductDAO();
		ProductDTO dto = dao.delete(num);
		ArrayList<ProductDTO> list = dao.product_list();
		
		System.out.println();
		System.out.println("--------------------------------------[메뉴]---------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.admin.display();
			break;
		default:
			System.exit(0);
		}		
		
	
		} 
	}

