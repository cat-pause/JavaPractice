package view;

import java.util.Scanner;

import product.ProductDAO;
import product.ProductDTO;
import user.UserDAO;
import user.UserDTO;

public class Order {

	private Scanner scan;
	public Order(Scanner scan) {
		this.scan = scan;
	}
	public void display(int num ,String id,  int qty) {
		ProductDAO dao = new ProductDAO();
		UserDAO ud = new UserDAO();
		ProductDTO dto = null;
		
		int count = dao.check_stock(num);
		int price = dao.purchase(num);
		int balance = ud.my_money(id);
		
		if( count < qty) {
			System.out.println("재고가 부족합니다.");
			
		}else if(count >= qty) {
			
			if(balance < qty * price) {
				
				System.out.println("잔액이 부족합니다.");
				
			}else if(balance >= qty * price) {
				dto = dao.order_product(num, id, qty);
				System.out.println("주문 완료 되었습니다.");
				
				System.out.println("\t\t[주문 상세 조회]\t");
				System.out.printf("%-6s\t: %d\n",
						"상품번호:",dto.getNum());
				System.out.printf("%-6s\t: %s\n",
						"상품:",dto.getName());
				System.out.printf("%-6s\t: %d\n",
						"주문금액:",dto.getPrice()* qty);
				System.out.printf("%-6s\t: %d\n",
						"주문수량:",qty);		
				
		}else;
			
			
		System.out.println();
		System.out.println("--------------------------------------[메뉴]---------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.user.display();
			break;
		default:
			System.exit(0);
		} 	
	}
	
	}
}
