package view;

import java.util.ArrayList;
import java.util.Scanner;

import product.ProductDAO;
import product.ProductDTO;

public class AdminMode {
	private Scanner scan;

	public AdminMode(Scanner scan) {
		this.scan = scan;
	}

	public void display() {
		// ProductDTO dto1= new ProductDTO();
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> list = dao.product_list();

		System.out.println("\t\t\t\t[상품목록]");
		System.out.println("상품번호\t상품명\t\t\t\t제조사\t\t\t상품 가격\t상품 수량(재고)");
		for (ProductDTO dto : list) {
			System.out.printf("%-3d\t\t", dto.getNum());
			System.out.printf("%-15s\t\t", dto.getName());
			System.out.printf("%-10s\t\t", dto.getCompany());
			System.out.printf("%7d\t\t\t", dto.getPrice());
			System.out.printf("%3d\t\t\n", dto.getQty());

		} 
	
		System.out.println(
				"--------------------------------------[메뉴]---------------------------------------------------\n");
		System.out.println("메뉴를 선택하세요");
		System.out.println("1.상품 조회  2.상품 추가 3.상품 삭제  4.재고 관리  0.로그아웃");
		System.out.print("선택 :  ");
		switch (scan.nextInt()) {
		case 1:
			System.out.println();
			System.out.println("=======================================[상품 조회]=========================================================\n");
			System.out.println();
			System.out.println("1. 상품 이름 검색  2. 출판사 검색");
			int menu = scan.nextInt();
			if (menu == 1) {
				System.out.print("상품명을 입력하세요: ");
				String name = scan.next()+scan.nextLine();
				View.search.display_name(name);
			} else if(menu == 2) {
				System.out.print("출판사를 입력하세요: ");
				String company = scan.next()+scan.nextLine();
				View.search.display_company(company);
			}
			break;
		case 2:
			System.out.println();
			System.out.println("=======================================[상품 추가]=========================================================\n");
			System.out.println("상품정보를 추가하세요");
			System.out.println("상품명: ");
			String name= scan.next()+scan.nextLine();
			System.out.println("회사: ");
			String company =  scan.next()+scan.nextLine();
			System.out.println("가격:");
			int price= scan.nextInt();
			System.out.println("수량: ");
			int qty = scan.nextInt();
			View.insert.display(name, company, price, qty);
			break;
		case 3:
			System.out.println();
			System.out.println("=======================================[상품 삭제]=========================================================\n");
			System.out.println("삭제 할 상품번호를 입력하세요 : ");
			int num = scan.nextInt();
			View.delete.display(num);	
			break;
		case 4:
			System.out.println();
			System.out.println("=======================================[재고 관리]=========================================================\n");
			System.out.println("1.입고관리    2.출고관리");
			System.out.println("선택하세요: ");
			int m = scan.nextInt();
			if(m == 1) {
				System.out.println("상품번호를 입력하세요.: ");
				int no = scan.nextInt();
				System.out.println("상품수량을 입력하세요.: ");
				int add = scan.nextInt();
				View.stock.add_stock(add, no);	
			}else if(m == 2) {
				System.out.println("상품번호를 입력하세요.: ");
				int no = scan.nextInt();
				System.out.println("상품수량을 입력하세요.: ");
				int add = scan.nextInt();
				View.stock.minus_stock(add, no);	
			}
			
			break;
		default:
			System.out.println();
			System.out.println("=======================================[로그 아웃]=========================================================\n");
			System.exit(0);
			
		}
	
	}

}
