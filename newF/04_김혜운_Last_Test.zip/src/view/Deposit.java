package view;

import java.util.Scanner;

import user.UserDAO;
import user.UserDTO;

public class Deposit {

	private Scanner scan;
	private int num;//
	private int qty;//

	public Deposit(Scanner scan) {
		this.scan = scan;
	}
	public void display_list(String id) {
		UserDAO dao = new UserDAO();
		int money = dao.my_money(id);
		
		System.out.println("\t\t[잔액조회]\t");
		System.out.printf("%-6s\t: %d\n",
				"잔액:",money);
		
		System.out.println();
		System.out.println("--------------------------------------[메뉴]---------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.user.display();
			break;
		case 2:
			View.order.display(num, id, qty);
		default:
			System.exit(0);   
		}	
		
		
	}
	public void display_add(int money,String id) {
		UserDAO dao = new UserDAO();
		UserDTO dto = dao.add_money(money, id);
		
		System.out.println("\t\t[잔액조회]\t");
		System.out.printf("%-6s\t: %s\n",
				"아이디:",dto.getId());
		System.out.printf("%-6s\t: %d\n",
				"잔액:",dto.getMoney());
		
		System.out.println();
		System.out.println("--------------------------------------[메뉴]---------------------------------------------------");
		System.out.println("1.상품목록  0.종료");
		System.out.println("선택: ");
		switch(scan.nextInt()) {
		case 1:
			View.user.display();
			break;
		case 2:
			View.order.display(money, id, money);
		default:
			System.exit(0);
		}				
	}
}
