package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;


import product.ProductDAO;
import product.ProductDTO;

public class UserDAO {
	private Scanner scan; //여러번 사용하기 위해서 필드로 선언
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	//드라이버 연결 메소드
	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn
			= DriverManager.getConnection(
					"jdbc:oracle:thin:@211.223.59.99:1521:xe","smart04", "0000");
			//System.out.println("db연결");
		}catch(Exception e) {
			System.out.println("db 연결 오류");
		}
	}
	
	//사용자로그인할 메소드
	public UserDTO login(String id, String pw){
		
		UserDTO dto= null; //2.정보를 담을 데이터 객체 생성- 초기값은 널값
		
		 //db연결
		 connect(); 
		 String sql 
		 		= "select id, pw, admin "
		 		+ "from tbl_java_user "
		 		+ "where id = ? and pw = ?";
		 
		 
		try {
			 ps = conn.prepareStatement(sql); //쿼리문에 ? 있으면 값을 담는다
			 ps.setString(1, id);
			 ps.setString(2, pw);
			
			 rs = ps.executeQuery(); //쿼리문 실행
			 if(rs.next()) {//데이터가 있으면
				 dto = new UserDTO(); //1. 정보를 담을 데이터 객체 생성
				 dto.setId(rs.getString("id"));
				 dto.setPw(rs.getString("pw"));
				 dto.setAdmin(rs.getString("admin"));
				 
				 
			}
		} catch (Exception e) {
			System.out.println("사용자로그인 오류");
			System.out.println("원인: " + e.getMessage());
		}finally {
			//자원회수처리
			disconnect();
			
		}
		return dto; //사용자의 정보(비번, admin알려줄)반환(주소) 
	}
	
	//자원회수처리 메소드
	public void disconnect() {
		if(rs!=null) {try {rs.close();}catch (Exception e) {} }
		if(ps!=null) {try {ps.close();}catch (Exception e) {} }
		if(conn!=null) {try {conn.close();}catch (Exception e) {} }
	}
	
	
	
	//잔액 조회 메소드
	public int my_money(String id) {
		int money = 0;
		connect();
			
			String sql
			="SELECT money "
					+"FROM tbl_java_user "		
					+"WHERE id = ?";
			
		try {
			 ps = conn.prepareStatement(sql); 
			 ps.setString(1, id);
			 rs = ps.executeQuery();
			 
			 if(rs.next()) {//데이터가 있으면
				 money = ( rs.getInt("money") );
				 
			 }
			
		} catch (Exception e) {
			System.out.println("잔액조회 오류");
			System.out.println("원인 : " + e.getMessage());
		}finally {
			disconnect();
		}
		return money;
	}
	
	//잔액 추가 메소드
	public UserDTO add_money(int money, String id) {
		UserDTO dto = null;
		connect();
			
			String sql1
			="UPDATE tbl_java_user "
			+"SET money =  money + ? "
			+"WHERE id = ?";
			
			String sql2
			="select * from tbl_java_user WHERE id = ?";	
		try {
			 ps = conn.prepareStatement(sql1); 
			 ps.setInt(1, money);
			 ps.setString(2,id);
			 ps.executeUpdate();
			 
			 ps = conn.prepareStatement(sql2);
			 ps.setString(1,id);
			 rs= ps.executeQuery();
			 if(rs.next()) {
				 
				 dto = new UserDTO();
				 dto.setMoney(rs.getInt("money")); 
				 dto.setId(rs.getString("id"));
			 }
 			 
			
		} catch (Exception e) {
			System.out.println("잔액추가 오류");
			System.out.println("원인 : " + e.getMessage());
		}finally {
			disconnect();
		}
		return dto;
	}
	

	
			
		
}
