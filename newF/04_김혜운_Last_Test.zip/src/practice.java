
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class practice {
	public static void main(String[] args) {
		try {
			//0.ojdbc8.jar파일 연결
			//1. 드라이버 연결
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이버 로딩완료");
			
			//DB연결 위치설정하기
			 Connection conn = DriverManager.getConnection(
					 "jdbc:oracle:thin:@211.223.59.99:1521:xe","smart04", "0000");
			System.out.println("DB연결성공");
		
			
			//쿼리문 실행
			String sql ="select * from tbl_java_user";
			
			Statement st = conn.createStatement(); 
			ResultSet rs = st.executeQuery(sql);
			
			while(rs.next()) {
				String id =	rs.getString("id");
				String pw = rs.getString("pw");
				String name = rs.getString("name");
				String email = rs.getString("email");
				int money = rs.getInt("money");
					
				System.out.printf("%s %s %s %s %d\n", id, pw, name, email, money);
			}
			rs.close();
			st.close();
			conn.close();
			
			
		}catch (ClassNotFoundException e ) {
			e.printStackTrace();

		}catch(SQLException e) {
			e.printStackTrace();
		}
				
		
		
	}
	
	
}
