package test;

import user.UserDTO;

public class Logininfo {
	static public UserDTO logininfo;
}//class
