package test;

import product.ProductDTO;

public class Productinfo {
	static public ProductDTO productInfo;
}//class
