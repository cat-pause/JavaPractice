package user;


import java.sql.SQLException;
import java.util.ArrayList;

import database.DBConnect;
import product.ProductDTO;

public class UserDAO extends DBConnect {
	//로그인 기능
	public Object[] login(String id, String pw) {
		Object a[]= new Object[2]; 
		connect();
		String sql 
		= "select * "
		+ "from tbl_java_user "
		+ "where id = ? ";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			if(rs.next()) {
				if(rs.getString("pw").contentEquals(pw)) {
					UserDTO dto = new UserDTO();
					dto.setId(rs.getString("id"));
					dto.setPw(rs.getString("pw"));
					dto.setName(rs.getString("name"));
					dto.setAdmin(rs.getString("admin"));
					dto.setEmail(rs.getString("email"));
					dto.setMoney(rs.getInt("money"));
					a[0] = dto;
					if(rs.getString("admin").contentEquals("Y")) {
						a[1] = 1;	//관리자 
					}else {
						a[1] = 2;	//유저
					}
				}else {
					a[1] = 0;		//비밀번호 틀림
				}
			}else {
				a[1] =  -1;			//아이디 틀림
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return a;
	}
	//회원가입 기능
	public int join(UserDTO dto) {
		connect();
		int num = 0;
		String sql 
		= "insert into tbl_java_user "
		+ "(id, pw, name, admin, email) "
		+ "values(?, ?, ?, ?, ? )";
		try {
			ps = conn.prepareStatement(sql);
				ps.setString(1, dto.getId());
				ps.setString(2, dto.getPw());
				ps.setString(3, dto.getName());
				ps.setString(4, "N");
				ps.setString(5, dto.getEmail());
				int count = ps.executeUpdate();
				if( count>0 ) {
					num = count;
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disconnect();
		}
		return num;
	}
	//아이디 중복확인 기능
	public boolean idPossible(String id) {
		connect();
		boolean use = true;
		String sql 
		= "select * "
		+ "from tbl_java_user "
		+ "where id = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			use = rs.next();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return use;
	}
	//ID 찾기
	public String findId(UserDTO dto) {
		connect();
		String id = null;
		String sql 
		= "select id "
		+ "from tbl_java_user "
		+ "where name = ? "
		+ "and email = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getEmail());
			rs = ps.executeQuery();
			while( rs.next() ) { 
				id = rs.getString("id");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return id;
	}
	
	//PW 찾기
	public String findPw(UserDTO dto) {
		connect();
		String pw = null;
		String sql 
		= "select pw "
		+ "from tbl_java_user "
		+ "where id = ? "
		+ "and email = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getEmail());
			rs = ps.executeQuery();
			while( rs.next() ) { 
				pw = rs.getString("pw");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return pw;
	}
	
	
	//회원관리 기능
	public ArrayList<UserDTO> userList() {
		connect();
		ArrayList<UserDTO> list = new ArrayList<UserDTO>();
		String sql 
		= "select * "
		+ "from tbl_java_user "
		+ "order by 1";
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while( rs.next() ) { 
				UserDTO dto = new UserDTO();
				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setAdmin(rs.getString("admin"));
				dto.setEmail(rs.getString("email"));
				dto.setMoney(rs.getInt("money"));
				list.add(dto);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return list;
	}
	// 회원 검색 기능
	public UserDTO userSearch(String id) {
		connect();
		UserDTO dto = new UserDTO();
		String sql 
		= "select * "
		+ "from tbl_java_user "
		+ "where id = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			while( rs.next() ) { 
				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setAdmin(rs.getString("admin"));
				dto.setEmail(rs.getString("email"));
				dto.setMoney(rs.getInt("money"));
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return dto;
	}
	//유저 정보 수정 기능(관리자 모드)
	public int userUpdate(UserDTO dto) {
		connect();
		int count = 0;
		try {
			
			String sql
			= "update tbl_java_user "
			+ "set pw = ?, name = ?, admin = ?, email = ?, money = ? "
			+ "where id = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, dto.getPw());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getAdmin());
			ps.setString(4, dto.getEmail());
			ps.setInt(5, dto.getMoney());
			ps.setString(6, dto.getId());
			count = ps.executeUpdate();
			if( count>0 ) {
				System.out.println("변경저장 완료");
			}
		}catch(Exception e) {
			return count;
		}finally {
			disconnect();
		}
		return count;
	}
	
	// 주문 완료 후 잔액변경 기능
	public int orderMoney(String id, int total){
		connect();
		int count = 0;
		try {
			
			String sql
			= "update tbl_java_user "
			+ "set money = money - ? "
			+ "where id = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, total);
			ps.setString(2, id);
			count = ps.executeUpdate();
			if( count>0 ) {
				System.out.println("변경저장 완료");
			}
		}catch(Exception e) {
			return count;
		}finally {
			disconnect();
		}
		return count;
	}
	
	//금액 충전 기능
	public int chargeMoney(String id, int money) {
		connect();
		int count = 0;
		try {
			
			String sql
			= "update tbl_java_user "
			+ "set money = ? "
			+ "where id = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, money);
			ps.setString(2, id);
			count = ps.executeUpdate();
			if( count>0 ) {
				System.out.println("변경저장 완료");
			}
		}catch(Exception e) {
			return count;
		}finally {
			disconnect();
		}
		return count;
	}
}
	
	

