package user;

public class UserInfo {
	public static UserDTO logininfo;
}
