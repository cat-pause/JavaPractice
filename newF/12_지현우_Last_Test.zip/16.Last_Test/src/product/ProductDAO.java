package product;
import java.sql.SQLException;
import java.util.ArrayList;

import database.DBConnect;
import user.UserInfo;

public class ProductDAO extends DBConnect  {
	//상품 전체 목록 기능
	public ArrayList<ProductDTO> allList() {
		connect();
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		String sql 
		= "select * "
		+ "from tbl_java_product "
		+ "order by 1";
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while( rs.next() ) { 
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num") );
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				list.add(dto);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return list;
	}
	// 상품 추가 기능
	public int insertProduct(ArrayList<ProductDTO> list){
		connect();
		int num = 0;
		String sql 
		= "insert into tbl_java_product "
		+ "(num, name, company, price, qty) "
		+ "values(tbl_java_product_seq.nextval, ?, ?, ?, ? )";
		try {
			ps = conn.prepareStatement(sql);
			for(int i=0;i<list.size();i++) {
				ps.setString(1, list.get(i).getName());
				ps.setString(2, list.get(i).getCompany());
				ps.setInt(3, list.get(i).getPrice());
				ps.setInt(4, list.get(i).getQty());
				int count = ps.executeUpdate();
				if( count>0 ) {
					num++;
				}else {
					System.out.println((num+1)+"번째 등록 오류");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disconnect();
		}
		return num;
	}
	//상품명 검색 기능
	public ArrayList<ProductDTO> nameList(String name) {
		connect();
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		String sql 
		= "select * "
		+ "from tbl_java_product "
		+ "where name like '%'|| ? ||'%'";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, name);
			rs = ps.executeQuery();
			while( rs.next() ) { 
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num") );
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				list.add(dto);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return list;
	}
	//회사명 검색 기능
	public ArrayList<ProductDTO> companyList(String company) {
		connect();
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		String sql 
		= "select * "
		+ "from tbl_java_product "
		+ "where company like '%'|| ? ||'%'";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, company);
			rs = ps.executeQuery();
			while( rs.next() ) { 
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num") );
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				list.add(dto);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return list;
	}
	//상품 삭제 기능
	public int deleteProduct(int cnt){
		connect();
		int count = 0;
		String sql 
		= "delete from tbl_java_product "
		+ "where num = ?";
		try {
			ps = conn.prepareStatement(sql);
				ps.setInt(1, cnt);
				count = ps.executeUpdate();
				if( count>0 ) {
					System.out.println("삭제 커밋");
				}
		} catch (SQLException e) {
			return count;
		}finally {
			disconnect();
		}
		return count;
	}
	//장바구니 삭제
	public int deleteBasket(int cnt){
		connect();
		int count = 0;
		String sql 
		= "delete from tbl_shopping_basket "
		+ "where basket_num = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, cnt);
			count = ps.executeUpdate();
			if( count>0 ) {
				System.out.println("삭제 커밋");
			}
		} catch (SQLException e) {
			return count;
		}finally {
			disconnect();
		}
		return count;
	}
	//상품 재고 관리 기능
	public int updateProduct(ProductDTO dto, int num) {
		connect();
		int count = 0;
		try {
			
			String sql
			= "update tbl_java_product "
			+ "set num = ?, name = ?, company = ?, "
			+ "price = ?, qty = ? "
			+ "where num = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, dto.getNum());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getCompany());
			ps.setInt(4, dto.getPrice());
			ps.setInt(5, dto.getQty());
			ps.setInt(6, num);
			count = ps.executeUpdate();
			if( count>0 ) {
				System.out.println("변경저장 완료");
			}
		}catch(Exception e) {
			return count;
		}finally {
			disconnect();
		}
		return count;
	}
	//상품번호 검색 기능
		public ProductDTO numList(int cnt) {
			connect();
			ProductDTO dto = new ProductDTO();
			String sql 
			= "select * "
			+ "from tbl_java_product "
			+ "where num= ?";
			try {
				ps = conn.prepareStatement(sql);
				ps.setInt(1, cnt);
				rs = ps.executeQuery();
				while( rs.next() ) { 
					dto.setNum(rs.getInt("num") );
					dto.setName(rs.getString("name"));
					dto.setCompany(rs.getString("company"));
					dto.setPrice(rs.getInt("price"));
					dto.setQty(rs.getInt("qty"));
				}
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				disconnect();
			}
			return dto;
		}
		//아몰라
		public BasketDTO basketNumList(int cnt) {
			connect();
			BasketDTO dto = new BasketDTO();
			String sql 
			= "select * "
					+ "from tbl_java_product "
					+ "where num = ?";
			try {
				ps = conn.prepareStatement(sql);
				ps.setInt(1, cnt);
				rs = ps.executeQuery();
				while( rs.next() ) { 
					dto.setNum(rs.getInt("num") );
					dto.setName(rs.getString("name"));
					dto.setCompany(rs.getString("company"));
					dto.setPrice(rs.getInt("price"));
					dto.setQty(rs.getInt("qty"));
				}
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				disconnect();
			}
			return dto;
		}
		//장바구니에서 주문할때  상품찾는 기능
		public BasketDTO oderBasketNumList(int cnt) {
			connect();
			BasketDTO dto = new BasketDTO();
			String sql 
			= "select * "
			+ "from tbl_shopping_basket "
			+ "where basket_num= ?";
			try {
				ps = conn.prepareStatement(sql);
				ps.setInt(1, cnt);
				rs = ps.executeQuery();
				while( rs.next() ) { 
					dto.setNum(rs.getInt("num") );
					dto.setBasket_num(rs.getInt("basket_num") );
					dto.setName(rs.getString("name"));
					dto.setCompany(rs.getString("company"));
					dto.setPrice(rs.getInt("price"));
					dto.setQty(rs.getInt("qty"));
				}
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				disconnect();
			}
			return dto;
		}
	//주문 하기
		public int orderProduct(int num, int qty){
			connect();
			int count = 0;
			try {
				
				String sql
				= "update tbl_java_product "
				+ "set qty = qty - ? "
				+ "where num = ?";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, qty);
				ps.setInt(2, num);
				count = ps.executeUpdate();
				if( count>0 ) {
					System.out.println("변경저장 완료");
				}
			}catch(Exception e) {
				return count;
			}finally {
				disconnect();
			}
			return count;
		}
		//장바구니 주문 하기
		public int orderBasketProduct(int num, int qty, int basket_num){
			connect();
			int count = 0;
			int count1 = 0;
			try {
				String sql
				= "update tbl_java_product "
						+ "set qty = qty - ?"
						+ "where num = ?";
				String sql1
				= "update tbl_shopping_basket "
				+ "set mode_num = 2, order_date = sysdate "
				+ "where basket_num = ?";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, qty);
				ps.setInt(2, num);
				count = ps.executeUpdate();
				ps = conn.prepareStatement(sql1);
				ps.setInt(1, basket_num);
				count1 = ps.executeUpdate();
				if( count>0 && count1>0 ) {
					System.out.println("변경저장 완료");
				}
			}catch(Exception e) {
				return count;
			}finally {
				disconnect();
			}
			return count+count1;
		}
		//장바구니 추가 기능
		public int addBasket(BasketDTO basket) {
			connect();
			int count = 0;
			String sql1 
			= "insert into tbl_shopping_basket "
			+ "(basket_num, id, num, name, company, price, qty, mode_num) "
			+ "values(tbl_shopping_basket_seq.nextval, ?, ?, ?, ?, ?, ?, 1 )";
			try {
				ps = conn.prepareStatement(sql1);
					ps.setString(1, basket.getId());
					ps.setInt(2, basket.getNum());
					ps.setString(3, basket.getName());
					ps.setString(4, basket.getCompany());
					ps.setInt(5, basket.getPrice());
					ps.setInt(6, basket.getQty());
					
					count = ps.executeUpdate();
					
					if( count>0 ) {
						System.out.println("장바구니 완료");
					}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				disconnect();
			}
			return count;
		
		}
		//장바구니 목록 기능
	public ArrayList<BasketDTO> basketList(String id){
		connect();
		ArrayList<BasketDTO> list = new ArrayList<BasketDTO>();
		String sql 
		= "select * "
		+ "from tbl_shopping_basket "
		+ "where id = ?"
		+ "and mode_num = 1 "
		+ "order by 1";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			while( rs.next() ) { 
				BasketDTO dto = new BasketDTO();
				dto.setBasket_num(rs.getInt("basket_num"));
				dto.setNum(rs.getInt("num"));
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				dto.setTotal(dto.getPrice()*dto.getQty());
				dto.setMode_num(rs.getInt("mode_num"));
				list.add(dto);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return list;
	}	
	//주문현황 목록 기능
	public ArrayList<BasketDTO> orderStatusList(String id){
		connect();
		ArrayList<BasketDTO> list = new ArrayList<BasketDTO>();
		String sql 
		= "select * "
				+ "from tbl_shopping_basket "
				+ "where id = ?"
				+ "and mode_num = 2 "
				+ "order by 1";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			while( rs.next() ) { 
				BasketDTO dto = new BasketDTO();
				dto.setBasket_num(rs.getInt("basket_num"));
				dto.setNum(rs.getInt("num"));
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				dto.setOrder_date(rs.getTimestamp("order_date"));
				dto.setTotal(dto.getPrice()*dto.getQty());
				dto.setMode_num(rs.getInt("mode_num"));
				list.add(dto);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return list;
	}	
		
}
	
