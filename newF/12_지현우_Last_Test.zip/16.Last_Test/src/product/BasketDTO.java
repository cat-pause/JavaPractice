package product;

import java.sql.Date;
import java.sql.Timestamp;

public class BasketDTO extends ProductDTO {
	int basket_num, mode_num, total;
	String id;
	Timestamp order_date;
	
	public Timestamp getOrder_date() {
		return order_date;
	}
	public void setOrder_date(Timestamp order_date) {
		this.order_date = order_date;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getBasket_num() {
		return basket_num;
	}
	public void setBasket_num(int basket_num) {
		this.basket_num = basket_num;
	}
	public int getMode_num() {
		return mode_num;
	}
	public void setMode_num(int mode_num) {
		this.mode_num = mode_num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}
