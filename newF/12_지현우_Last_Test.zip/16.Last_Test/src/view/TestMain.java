package view;

import java.util.Scanner;

public class TestMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		View.login = new LoginView(sc);
		View.mainmenu = new MainMenu(sc);
		View.productView = new ProductView(sc);
		View.userView = new UserView(sc);
		
		View.mainmenu.display();
		
		sc.close();

	}
}
