package view;

public class View {
	static LoginView login;
	static MainMenu mainmenu;
	static ProductView productView;
	static UserView userView;
}
