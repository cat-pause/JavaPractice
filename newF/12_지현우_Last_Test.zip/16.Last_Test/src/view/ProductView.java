package view;

import java.util.ArrayList;
import java.util.Scanner;

import product.BasketDTO;
import product.ProductDAO;
import product.ProductDTO;
import user.UserDAO;
import user.UserDTO;
import user.UserInfo;

public class ProductView {
	private Scanner sc;
	
	public ProductView(Scanner sc) {
		this.sc = sc;
	}
	// 전체 상품 목록 뷰
	public void listView() {
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> list = dao.allList();
		System.out.println("\t\t\t\t[ 전체 상품 목록 ]");
		System.out.println("=============================================================================================");
		System.out.println("번호\t상품명\t\t\t\t회사명\t\t\t가격\t\t\t수량");
		System.out.println("=============================================================================================");
		for(ProductDTO dto : list) {
			System.out.print(dto.getNum() + "\t");
			System.out.printf("%-20s \t",dto.getName());
			System.out.printf("%-15s \t", dto.getCompany());
			System.out.printf("%-15d \t", dto.getPrice());
			if(dto.getQty() == 0) {
				System.out.print("[품절]\n\n");
			}else {
				System.out.printf("%s \n\n", dto.getQty());
			}
		}		
		System.out.println("=============================================================================================\n");
	}
	// 관리자 상품 목록 뷰
	public void adminListView() {
		
		listView();
		
		System.out.println("1.상품검색 2.상품추가 3.상품삭제 4.재고관리 5.회원관리 6.로그아웃");
		System.out.print("선택: ");
		switch( Integer.parseInt(sc.nextLine()) ) {
		case 1:
			searchMenuView();
		case 2:
			insertView();
			break;
		case 3:
			deleteView();
			break;
		case 4:
			qcyManageView();
			break;
		case 5:
			System.out.println("1. 회원 조회 2. 회원 정보 수정");
			if(Integer.parseInt(sc.nextLine()) ==1) {
				View.userView.userView();
			}else {
				View.userView.userUpdateView();
			}
			break;
			
		case 6:
			System.out.println("로그아웃 되었습니다.\n 메인 화면으로 넘어갑니다\n");
			View.mainmenu.display();
			break;
			
		default:
			System.exit(0);
		}
	}
	// 사용자 상품 목록 뷰
	public void usersListView() {
		listView();
		System.out.println(UserInfo.logininfo.getName()+"님\t\t\t 보유금액 : "+UserInfo.logininfo.getMoney()+"\n");
		System.out.println("1.상품검색 2.상품 주문 3.장바구니 4.주문현황 5.금액 충전 6.로그아웃");
		System.out.print("선택: ");
		switch( Integer.parseInt(sc.nextLine()) ) {
		case 1:
			searchMenuView();
		case 2:
			orderView();
			break;
		case 3:
			View.userView.basketView();
			break;
		case 4:
			View.userView.orderStatusView();
			break;
		case 5:
			View.userView.chargeMoneyView();
			break;
		case 6:
			System.out.println("로그아웃 되었습니다.\n 메인 화면으로 넘어갑니다\n");
			View.mainmenu.display();
			break;
		
		default:
			System.exit(0);
		}
	}
	
	// 상품명 검색 뷰
	public void nameSearchView(String name) {
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> list = dao.nameList(name);
		System.out.println("\t\t\t\t[ 검색한 상품 목록 ]");
		System.out.println("=============================================================================================");
		System.out.println("번호\t상품명\t\t\t\t회사명\t\t\t가격\t\t\t수량");
		System.out.println("=============================================================================================");
		for(ProductDTO dto : list) {
			System.out.print(dto.getNum() + "\t");
			System.out.printf("%-20s \t",dto.getName());
			System.out.printf("%-15s \t", dto.getCompany());
			System.out.printf("%-15d \t", dto.getPrice());
			if(dto.getQty() == 0) {
				System.out.print("[품절]\n\n");
			}else {
				System.out.printf("%s \n\n", dto.getQty());
			}
		}		
		System.out.println("=============================================================================================\n");
		if(UserInfo.logininfo.getAdmin().equals("Y")) {
			System.out.println("1. 상품 삭제 2.재고 관리 3.돌아가기");
			int cnt = Integer.parseInt(sc.nextLine());
			if(cnt == 1) {
				deleteView();
			}else if (cnt == 2) {
				qcyManageView();
			}else {
				adminListView();
			}
		}else {
			System.out.println("1. 구매하기 2. 돌아가기 ");
			int cnt = Integer.parseInt(sc.nextLine());
			if(cnt == 1) {
				orderView();
			}else {
				usersListView();
			}
		}
	}
	//회사명 검색 뷰
	public void companySearchView(String company) {
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> list = dao.companyList(company);
		System.out.println("\t\t\t\t[ 검색한 상품 목록 ]");
		System.out.println("=============================================================================================");
		System.out.println("번호\t상품명\t\t\t\t회사명\t\t\t가격\t\t\t수량");
		System.out.println("=============================================================================================");
		for(ProductDTO dto : list) {
			System.out.print(dto.getNum() + "\t");
			System.out.printf("%-20s \t",dto.getName());
			System.out.printf("%-15s \t", dto.getCompany());
			System.out.printf("%-15d \t", dto.getPrice());
			if(dto.getQty() == 0) {
				System.out.print("[품절]\n\n");
			}else {
				System.out.printf("%s \n\n", dto.getQty());
			}
		}		
		System.out.println("=============================================================================================\n");
		if(UserInfo.logininfo.getAdmin().equals("Y")) {
			System.out.println("1. 상품 삭제 2.재고 관리 3.돌아가기");
			int cnt = Integer.parseInt(sc.nextLine());
			if(cnt == 1) {
				deleteView();
			}else if (cnt == 2) {
				qcyManageView();
			}else {
				adminListView();
			}
		}else {
			System.out.println("1. 구매하기 2. 돌아가기 ");
			int cnt = Integer.parseInt(sc.nextLine());
			if(cnt == 1) {
				orderView();
			}else {
				usersListView();
			}
		}
	}
	//상품 추가 등록 뷰
	public void insertView() {
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		System.out.println("------------ 상품 추가 등록 ------------");
		System.out.println();
		while(true){
			ProductDTO dto = new ProductDTO();
			System.out.print("상품명 : ");
			dto.setName(sc.nextLine());
			System.out.print("회사명: ");
			dto.setCompany(sc.nextLine());
			System.out.print("가격: ");
			dto.setPrice(Integer.parseInt(sc.nextLine()));
			System.out.print("수량: ");
			dto.setQty(Integer.parseInt(sc.nextLine()));
			list.add(dto);
			System.out.println("1. 계속하기 / 0(아무키). 종료");
			if(Integer.parseInt(sc.nextLine()) == 1) {
				continue;
			}else {
				int num = dao.insertProduct(list);
				System.out.println("총 "+num+"개의 상품이 입력되었습니다.");
				break;
			}
		}
		adminListView();
	}
	// 상품 삭제 뷰
	public void deleteView() {
		ProductDAO dao = new ProductDAO();
		
		while(true) {
			System.out.print("삭제할 상품 번호를 적으세요 : ");
			int cnt = Integer.parseInt(sc.nextLine());
			int num = dao.deleteProduct(cnt);
			if(num > 0) {
				System.out.println("삭제 완료");
				System.out.println("1.더 삭제하기 2. 그만하기");
				if(Integer.parseInt(sc.nextLine()) == 1) {
					listView();
					break;
				}else {
					adminListView();
					break;
				}
			}else {
				System.out.println("상품 번호를 잘못 입력하셨습니다. 다시 입력하세요");
			}
		}
	}
	//상품 관리(수정) 뷰
	public void qcyManageView() {
		while(true) {
			ProductDAO dao = new ProductDAO();
			ProductDTO dto = new ProductDTO();
			System.out.print("재고관리 할 상품 번호를 적으세요 : ");
			int cnt = Integer.parseInt(sc.nextLine());
			dto = dao.numList(cnt);
			System.out.printf("상품번호 : %d --->  ", dto.getNum());
			dto.setNum(Integer.parseInt(sc.nextLine()));
			System.out.printf("상품명 : %s --->  ", dto.getName());
			dto.setName(sc.nextLine());
			System.out.printf("회사명 : %s --->  ", dto.getCompany());
			dto.setCompany(sc.nextLine());
			System.out.printf("가격 : %d --->  ", dto.getPrice());
			dto.setPrice(Integer.parseInt(sc.nextLine()));
			System.out.printf("수량 : %d --->  ", dto.getQty());
			dto.setQty(Integer.parseInt(sc.nextLine()));
			int num = dao.updateProduct(dto, cnt);
			if(num > 0) {
				System.out.println("수정 완료");
				System.out.println("1.더 수정하기 2. 그만하기");
				if(Integer.parseInt(sc.nextLine()) == 1) {
					listView();
				}else {
					adminListView();
					break;
				}
			}else {
				System.out.println("잘못 입력하셨습니다. 다시 입력하세요");
				listView();
				break;
			}
		}
	}
	//주문하기 뷰
	public void orderView() {
		ProductDAO dao = new ProductDAO();
		ProductDTO dto = new ProductDTO();
		BasketDTO basket = new BasketDTO();
		UserDAO udao = new UserDAO();
		UserDTO user = UserInfo.logininfo;
		int pnum = 0;
		int unum = 0;
		int money = user.getMoney();
		
		while(true) {
			System.out.print("주문할 상품 번호를 적으세요 : ");
			int cnt = Integer.parseInt(sc.nextLine());
			basket = dao.basketNumList(cnt);
			dto = basket;
			basket.setId(user.getId());
			System.out.printf("주문할 상품 갯수를 적으세요(현재 수량: %d) : ", dto.getQty());
			int qty = Integer.parseInt(sc.nextLine());
			int total = dto.getPrice()*qty;
			if(qty > dto.getQty()) {
				System.out.println("주문하신 수량이 재고중인 수량보다 많습니다. 다시 주문해 주세요.");
				continue;
			}else if(qty ==0) {
				System.out.println("수량을 1이상으로 적어주세요.");
				continue;
			}else {
				basket.setQty(qty);
			}
	
			System.out.printf("주문하신 상품의 총 금액은 %d원 입니다.\n", total);
			System.out.print("1.주문하기 2.장바구니 3. 돌아가기 ");
			cnt = Integer.parseInt(sc.nextLine());
			if(cnt == 1) {
				if(money>= total) {
					pnum = dao.orderProduct(dto.getNum(), qty);
				}else {
					System.out.println("잔액이 부족합니다. 충전하세요!");
					usersListView();
					break;
				}
			}else if(cnt == 2) {
				int num = dao.addBasket(basket);
				if(num>0) {		
					System.out.println("장바구니에 추가되었습니다.");
					System.out.println("1. 계속 쇼핑하기  2.장바구니 가기 3. 나가기");
					cnt = Integer.parseInt(sc.nextLine());
					if(cnt == 1) {
						listView();
						continue;
					}else if(cnt == 2) {
						View.userView.basketView();
						break;
					}else {
						usersListView();
						break;
					}
				}else {
					System.out.println("장바구니 담기 실패!");
					continue;
				}
			}else {
				usersListView();
				break;
			}
			
			
			
			if(pnum > 0) {
				unum = udao.orderMoney(user.getId(), total);
				if(unum> 0) {
					UserInfo.logininfo.setMoney(user.getMoney() - total);
					System.out.println("구매 완료");
					System.out.println("1.더 구매하기 2. 그만하기");
					if(Integer.parseInt(sc.nextLine()) == 1) {
						listView();
						continue;
					}else {
						
						usersListView();
						break;
					}
				}
			}else {
				System.out.println("주문에 문제가 있습니다. 다시 주문해주세요.");
				continue;
			}
		}
	}
	
	// 상품명 검색, 회사명 검색 선택 뷰
	public void searchMenuView() {
		while(true) {
			System.out.print("1. 상품명으로 검색	2. 회사명으로 검색 	0.뒤로가기");
			int cnt = Integer.parseInt(sc.nextLine());
			if(cnt == 1) {
				System.out.print("상품명: ");
				String name = sc.nextLine();
				nameSearchView(name);
				break;
			}else if (cnt == 2) {
				System.out.print("회사명: ");
				String company = sc.nextLine();
				companySearchView(company);
				break;
			}else if(cnt == 0) {
				if(UserInfo.logininfo.getAdmin().equals("Y")) {
					adminListView();
					break;
				}else {
					usersListView();
					break;
				}
			
			}else {
				System.out.println("잘못입력했습니다 . 다시 입력하세요");
			}
		}
	}
}
