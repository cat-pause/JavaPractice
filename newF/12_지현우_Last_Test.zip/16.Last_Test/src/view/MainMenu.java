package view;

import java.util.Scanner;

public class MainMenu {
	private Scanner sc;
	
	public MainMenu(Scanner sc) {
		this.sc = sc;
	}
	public void display(){
		
		while(true) {			
			System.out.println("자바 미니프로젝트 <회원&상품 관리 프로그램>");
			System.out.print("1. 로그인 2. 회원가입 3. ID/PW 찾기 0.종료");
			int cnt = Integer.parseInt(sc.nextLine());
			if(cnt == 1) {
				View.login.display();
				break;
			}else if(cnt == 2) {
				View.userView.joinView();
				break;
			}else if(cnt == 3) {
				View.userView.findIdPwView();
				break;
			}else if(cnt == 0) {
				System.out.println("종료되었습니다.");
				break;
			}else {
				System.out.println("잘못입력하셨습니다. 다시 입력하세요.");
			}
		}
		
		
	}
}
