package view;

import java.util.ArrayList;
import java.util.Scanner;

import product.BasketDTO;
import product.ProductDAO;
import product.ProductDTO;
import user.UserDAO;
import user.UserDTO;
import user.UserInfo;

public class UserView {
	private Scanner sc;
	
	public UserView(Scanner sc) {
		this.sc = sc;
	}
	//회원 가입 뷰
	public void joinView() {
		UserDAO dao = new UserDAO();
		UserDTO dto = new UserDTO();
		System.out.println("[회원가입]");
		while(true) {
			System.out.print("아이디 : ");
			String id= sc.nextLine();
			if(dao.idPossible(id)) {
				System.out.println("사용중인 아이디입니다. 다시 입력해주세요.");
			}else {
				dto.setId(id);
				break;
			}
		}
		System.out.print("비밀번호 : ");
		dto.setPw(sc.nextLine()); 
		System.out.print("이름 : ");
		dto.setName(sc.nextLine());
		System.out.print("이메일 : ");
		dto.setEmail(sc.nextLine());
		int num = dao.join(dto);
		if(num>0) {
			System.out.println("회원가입이 완료되었습니다. 로그인해주세요");
			View.login.display();
		}else {
			System.out.println("가입 실패 ... 관리자에게 문의하세요!");
		}
		
		
	}
	//아이디/비번 찾기 뷰
	public void findIdPwView(){
		UserDTO dto = new UserDTO();
		UserDAO dao = new UserDAO();
		System.out.print("1. 아이디 찾기 2.비밀번호 찾기  :");
		int num = Integer.parseInt(sc.nextLine());
		if(num == 1) {
			System.out.print("이름을 입력해 주세요 : ");
			dto.setName(sc.nextLine());
			System.out.print("가입시 입력한 이메일을 입력해 주세요 : ");
			dto.setEmail(sc.nextLine());
			String id = dao.findId(dto);
			if(id == null) {
				System.out.println("정보를 잘못입력했거나 가입내역이 없습니다.");
				View.mainmenu.display();
			}else {
				System.out.println("ID :  "+ id);
				View.mainmenu.display();
			}
		}else {
			System.out.print("아이디를 입력해 주세요 : ");
			dto.setId(sc.nextLine());
			System.out.print("가입시 입력한 이메일을 입력해 주세요 : ");
			dto.setEmail(sc.nextLine());
			String pw = dao.findPw(dto);
			if(pw == null) {
				System.out.println("정보를 잘못입력했거나 가입내역이 없습니다.");
				View.mainmenu.display();
			}else {
				System.out.println("pw :  "+ pw);
				View.mainmenu.display();
			}
			
		}
	}
	//유저 리스트 목록 뷰
	public void userListView() {
		UserDAO dao = new UserDAO();
		ArrayList<UserDTO> list = dao.userList();
		System.out.println("\t\t\t\t[ 전체 회원 목록 ]");
		System.out.println("=======================================================================================");
		System.out.println("아이디\t이름\t\t   관리자모드\t\t이메일\t\t\t보유금액");
		System.out.println("=======================================================================================");
		for(UserDTO dto : list) {
			System.out.print(dto.getId() + "\t");
			System.out.printf("%-15s \t",dto.getName());
			System.out.printf("%-10s \t", dto.getAdmin());
			System.out.printf("%-10s \t", dto.getEmail());
			System.out.printf("%d \n\n", dto.getMoney());
		}		
		System.out.println("=======================================================================================\n");
	}
	//유저 조회 뷰
	public void userView() {
		userListView();
		System.out.print("1.회원정보 수정 2. 나가기 : ");
		if(Integer.parseInt(sc.nextLine()) ==1 ) {
			userUpdateView();
		}else {
			View.productView.adminListView();
		}
		
	}
	//유저 정보 수정 뷰
	public void userUpdateView() {
		userListView();
		UserDTO dto = new UserDTO();
		UserDAO dao = new UserDAO();
		while(true) {
			System.out.print("수정할 아이디를 입력해주세요 : ");
			String id= sc.nextLine();
			if(dao.idPossible(id)) {
				dto = dao.userSearch(id);
				System.out.printf("비밀번호 :  ****  --> ");
				dto.setPw(sc.nextLine());
				System.out.printf("이름 : %s --> ",dto.getName());
				dto.setName(sc.nextLine());
				System.out.printf("관리자 모드 : %s --> ",dto.getAdmin());
				dto.setAdmin(sc.nextLine());
				System.out.printf("이메일 : %s --> ",dto.getEmail());
				dto.setEmail(sc.nextLine());
				System.out.printf("보유 금액 : %d --> ",dto.getMoney());
				dto.setMoney(Integer.parseInt(sc.nextLine()));
				int num = dao.userUpdate(dto);
				if(num > 0) {
					System.out.println("회원 정보가 수정되었습니다.");
					userView();
					break;
				}else {
					System.out.println("회원 정보 수정에 문제가 생겼습니다.");
					userView();
					break;
				}
			}else {
				System.out.println("존재하지 않는 아이디입니다 다시 입력해주세요.");
			}
		}
		
	}
	
	//금액 충전 뷰
	public void chargeMoneyView() {
		UserDAO dao = new UserDAO();
		int money = UserInfo.logininfo.getMoney();
		System.out.println("보유중인 금액 : "+ money);
		System.out.print("충전할 금액을 입력하세요 :");
		int charge = Integer.parseInt(sc.nextLine());
		System.out.print(charge+"원   1.충전   2.취소 :");
		int num = Integer.parseInt(sc.nextLine());
		if(num == 1) {
			money = money + charge;
			num = dao.chargeMoney(UserInfo.logininfo.getId(), money);
			if(num > 0) {
				UserInfo.logininfo.setMoney(money);
				System.out.println("충전이 완료되었습니다. 감사합니다");
				View.productView.usersListView();
			}
		}else {
			System.out.println("메인 리스트 화면으로 돌아갑니다.");
			View.productView.usersListView();
		}		
	}
	//장바구니 뷰/ 장바구니 결제 뷰
	public void basketView() {
		int total = 0;
		BasketDTO basket = new BasketDTO();
		ProductDTO product = new ProductDTO();
		ProductDAO dao = new ProductDAO();
		UserDAO udao = new UserDAO();
		ArrayList<BasketDTO> list = dao.basketList(UserInfo.logininfo.getId());
		System.out.println("\t\t\t\t[ 장바구니 목록 ]");
		System.out.println("================================================================================================================");
		System.out.println("번호\t상품번호\t상품명\t\t\t\t회사명\t\t\t상품가격\t수량\t결제금액");
		System.out.println("================================================================================================================");
		for(BasketDTO dto : list) {
			System.out.print(dto.getBasket_num() + "\t");
			System.out.printf("%-10d \t",dto.getNum());
			System.out.printf("%-20s \t",dto.getName());
			System.out.printf("%-15s \t", dto.getCompany());
			System.out.printf("%-10d \t", dto.getPrice());
			System.out.printf("%d \t", dto.getQty());
			System.out.printf("%d \n\n", dto.getTotal());
			total = total+(dto.getPrice()*dto.getQty());
		}
		System.out.println("================================================================================================================\n");
		System.out.println("총액 : \t\t\t\t\t\t\t\t\t\t\t"+ total);
		System.out.println("================================================================================================================\n");
		System.out.println("1.주문하기 2.전체 주문하기  3. 삭제하기 4. 나가기");
		int choice = Integer.parseInt(sc.nextLine());
		if(choice == 1) {
			System.out.println("주문할 번호를 입력하세요 : ");
			int num = Integer.parseInt(sc.nextLine());
			basket = dao.oderBasketNumList(num);
			product = dao.numList(basket.getNum());
			
			int count = dao.orderBasketProduct(basket.getNum(),basket.getQty(),basket.getBasket_num());
			if(count>0) {
				if(UserInfo.logininfo.getMoney()>=basket.getPrice()*basket.getQty() ) {
					udao.orderMoney(basket.getId(), basket.getPrice()*basket.getQty());
					UserInfo.logininfo.setMoney(UserInfo.logininfo.getMoney()-basket.getPrice()*basket.getQty());
					System.out.println("결제완료");
					View.productView.usersListView();
				}else {
					System.out.println("잔액 부족합니다.");
					View.productView.usersListView();
				}
			}else {
				System.out.println("결제 오류 돌아갑니다.");
				View.productView.usersListView();
			}
		}else if(choice == 2) {
			System.out.println("장바구니 전체상품  주문합니다.");
			if(UserInfo.logininfo.getMoney()>= total) {
				int count = 0;
				for (BasketDTO dto : list) {
					count = dao.orderBasketProduct(dto.getNum(),dto.getQty(), dto.getBasket_num());
					if(count<0) {
						System.out.println("주문 오류 ! 관리자 문의");
					}
				}
				if(count>0) {
					udao.orderMoney(basket.getId(), total);
					UserInfo.logininfo.setMoney(UserInfo.logininfo.getMoney() - total);
					System.out.println("결제 완료!");
					View.productView.usersListView();
				}
			}else {
				System.out.println("잔액 부족합니다.");
				basketView();
			}
			
		}else if(choice == 3) {
			System.out.print("삭제할 번호를 적으세요 :");
			int num = Integer.parseInt(sc.nextLine());
			int count = dao.deleteBasket(num);
			if(count>0) {
				System.out.println("장바구니에서 선택한 상품을 삭제하였습니다.");
				System.out.println("장바구니로 돌아갑니다.");
				basketView();
			}else {
				System.out.println("장바구니 삭제 오류");
				View.productView.usersListView();
			}
		}else {
			View.productView.usersListView();
		}
	}
	
	// 주문 현황 뷰
	public void orderStatusView() {
		int total = 0;
		BasketDTO basket = new BasketDTO();
		ProductDTO product = new ProductDTO();
		ProductDAO dao = new ProductDAO();
		UserDAO udao = new UserDAO();
		ArrayList<BasketDTO> list = dao. orderStatusList(UserInfo.logininfo.getId());
		System.out.println("\t\t\t\t\t[ 주문 목록 ]");
		System.out.println("=========================================================================================================================================");
		System.out.println("결제일\t\t\t번호\t상품번호\t상품명\t\t\t\t회사명\t\t\t상품가격\t수량\t결제금액");
		System.out.println("=========================================================================================================================================");
		for(BasketDTO dto : list) {
			System.out.print(dto.getOrder_date() + "\t");
			System.out.print(dto.getBasket_num() + "\t");
			System.out.printf("%-10d \t",dto.getNum());
			System.out.printf("%-20s \t",dto.getName());
			System.out.printf("%-15s \t", dto.getCompany());
			System.out.printf("%-10d \t", dto.getPrice());
			System.out.printf("%d \t", dto.getQty());
			System.out.printf("%d \n\n", dto.getTotal());
			total = total+(dto.getPrice()*dto.getQty());
		}
		System.out.println("==========================================================================================================================================\n");	
		System.out.println("아무키나 입력하면 되돌아갑니다.");
		sc.nextLine();
		View.productView.usersListView();
	}
}
