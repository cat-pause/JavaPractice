package view;

import java.util.Scanner;

import product.BasketDTO;
import user.UserDAO;
import user.UserDTO;
import user.UserInfo;

public class LoginView {
	private Scanner sc;
	
	public LoginView(Scanner sc){
		this.sc = sc;
	}
	
	public void display() {
		String id, pw;
		UserDAO dao = new UserDAO();
		UserDTO dto = new UserDTO();
		while(true) {
			System.out.println("-------- 자바 미니 프로젝트 로그인 ---------");
			System.out.print("아이디를 입력하세요 : ");
			id = sc.nextLine();
			System.out.print("비밀번호를 입력하세요 : ");
			pw = sc.nextLine();
			
			Object[] login_cnt = dao.login(id, pw);
			UserInfo.logininfo = (UserDTO)login_cnt[0];
			dto = (UserDTO)login_cnt[0];
			
			if((Integer)login_cnt[1] == 1) {
				System.out.println(dto.getName()+"님 어서오세요. 관리자 모드로 넘어갑니다.");
				View.productView.adminListView();
				break;
			}else if((Integer)login_cnt[1] == 2) {
				System.out.println(dto.getName()+"님 어서오세요.");
				View.productView.usersListView();
				break;
			}else if((Integer)login_cnt[1] == 0) {
				System.out.println("비밀번호가 틀렸습니다.");
			}else if ((Integer)login_cnt[1] == -1) {
				System.out.println("존재하지 않는 회원입니다.");
			}
		}
	}

}
