package view;

import java.util.Scanner;

public class MainView {
	private Scanner sc;
	
	public MainView(Scanner sc){
		this.sc = sc;
	}
	
	public void display(){
		System.out.println("========================");
		System.out.println("1.로그인 0.종료");
		System.out.print("선택: ");
		String menu_S = sc.next();
		
		switch(menu_S){
			case "1" :
				View.loginV.lg_display();
				break;
			case "0" :
				System.out.println("시스템을 종료합니다...");
				System.exit(0);
				break;
			default :
				System.out.println("올바른 정보를 입력해주세요.");
				display();
				break;
		}//switch()
	}//display()
}
