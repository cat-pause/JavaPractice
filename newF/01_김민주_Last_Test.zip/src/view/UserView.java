package view;

import java.util.ArrayList;
import java.util.Scanner;

import test.ProductDAO;
import test.ProductDTO;
import test.UserDAO;

public class UserView {
	private Scanner sc;

	public UserView(Scanner sc){
		this.sc = sc;
	}
	
	public void user_display(String user_id){
		ProductDAO product_dao = new ProductDAO();
		ProductDTO product_dto = new ProductDTO();

		ArrayList<ProductDTO> list1 = product_dao.product_list();
		UserDAO user_dao = new UserDAO();
		
		System.out.println("========================");
		System.out.println("[사용자 모드]");
		System.out.println("[전체 상품 목록]");
		System.out.println("num\tname\t\t\t\tcompany\tprice\tqty");
		
		for(ProductDTO dto : list1){
			System.out.print(dto.getNum()+"\t");
			System.out.print(dto.getName()+"\t");
			System.out.print(dto.getCompany()+"\t");
			System.out.print(dto.getPrice()+"\t");
			System.out.println(dto.getQty());
		}//for()
		
		System.out.println("========================");
		System.out.println("1.금액 입력");
		System.out.print("입력: ");
		int input_price = sc.nextInt();
		
		// 보유 금액 확인
		user_dao.update_money(input_price, user_id);
		View.user_info = user_dao.recent_money(user_id);
		
		// 보유 금액 출력
		int user_money = View.user_info.getMoney();
		System.out.println("========================");
		System.out.println("보유 금액: " + user_money);
		System.out.println("========================");
		
		System.out.println("2.상품 주문");
		System.out.print("상품 번호를 입력하세요.: ");
		int product_num = sc.nextInt();
		product_dao.product_sth(product_num);
		System.out.print(product_num + "번을 주문하시겠습니까?(Y/N): ");
		switch(sc.next()){
			case "Y":
				//재고가 없을 경우
				product_dto = product_dao.product_qty(product_num);
				int recent_qty = product_dto.getQty();
				if(recent_qty == 0 || recent_qty < 0){
					System.out.println("해당 상품은 현재 재고가 없습니다.");
					System.out.println(product_num + "번, 주문을 취소하였습니다...");
				}
				//재고가 있을 경우
				else if(recent_qty != 0) {
					System.out.println(product_num + "번, 주문받았습니다^^!");
					
					// 보유 잔액과 해당 상품 가격 비교
					product_dto = product_dao.product_price(product_num);
					int compare_money_price = user_money - product_dto.getPrice();
					if(compare_money_price < 0){
						System.out.println("보유 잔액이 부족합니다.");
						System.out.println(product_num + "번, 주문을 취소하였습니다...");
						System.out.println("유저 화면으로 돌아갑니다.");
						View.userV.user_display(user_id);
					}else {
						product_dao.purchase_product(user_id, product_num);
						// 보유 잔액 출력
						View.user_info = user_dao.recent_money(user_id);
						int re_user_money = View.user_info.getMoney();
						System.out.println("잔액은 "+ re_user_money +"원 입니다.");
						//주문 완료된, 전체 상품 목록 출력
						ArrayList<ProductDTO> list2 = product_dao.product_list();
						System.out.println("[주문 완료 반영 전체 상품 목록]");
						System.out.println("num\tname\t\t\t\tcompany\tprice\tqty");
						
						for(ProductDTO dto : list2){
							System.out.print(dto.getNum()+"\t");
							System.out.print(dto.getName()+"\t");
							System.out.print(dto.getCompany()+"\t");
							System.out.print(dto.getPrice()+"\t");
							System.out.println(dto.getQty());
						}//for()
					}//if()
				}
				break;
			case "N":
				System.out.println(product_num + "번, 주문을 취소하였습니다...");
				break;
			default:
				System.out.println("잘못된 입력입니다..!");
				View.userV.user_display(user_id);
				break;
		}//switch()
		
		System.out.println("========================");
		System.out.println("3.로그아웃");
		System.out.print("로그아웃 하시겠습니까?(Y/N): ");
		switch(sc.next()){
			case "Y":
				System.out.println("시스템을 종료합니다...");
				System.exit(0);
				break;	
			case "N":
				System.out.println("유저 화면으로 돌아갑니다.");
				View.userV.user_display(user_id);
				break;
			default:
				System.out.println("잘못된 입력입니다..!");
				View.userV.user_display(user_id);
				break;
		}//switch()
	}//user_display()
}
