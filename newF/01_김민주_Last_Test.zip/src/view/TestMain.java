package view;

import java.util.Scanner;

public class TestMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		View.homeV = new MainView(sc);
		View.loginV = new LoginView(sc);
		View.userV = new UserView(sc);
		View.adminV = new AdminView(sc);
		
		View.homeV.display();
		sc.close();
	}
}
