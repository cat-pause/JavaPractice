package view;

import java.util.Scanner;

import test.UserDAO;

public class LoginView {
	private Scanner sc;

	public LoginView(Scanner sc){
		this.sc = sc;
	}
	
	public void lg_display(){
		System.out.println("========================");
		System.out.println("[로그인]");
		
		System.out.print("아이디 : ");
		String input_id = sc.next();
		System.out.print("비밀번호 : ");
		String input_pw = sc.next();
		
		UserDAO user = new UserDAO();
		
		do {
			View.user_info = user.user_check(input_id, input_pw);
			
			if(View.user_info.getAdmin().equals("Y")){
				View.adminV.ad_display();
			}else if(View.user_info.getAdmin().equals("N")){
				View.userV.user_display(View.user_info.getId());
			}else{
				System.out.println("시스템을 종료합니다...");
				System.exit(0);
			}
		}while(View.user_info == null);
		
	}//lg_display()
}
