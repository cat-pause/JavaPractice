package view;

import test.UserDTO;

public class View {
	static MainView homeV;
	static LoginView loginV;
	static AdminView adminV;
	static UserView userV;
	static UserDTO user_info;
}
