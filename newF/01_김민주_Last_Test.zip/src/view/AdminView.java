package view;

import java.util.ArrayList;
import java.util.Scanner;

import test.ProductDAO;
import test.ProductDTO;

public class AdminView {
	private Scanner sc;

	public AdminView(Scanner sc){
		this.sc = sc;
	}
	
	public void ad_display(){
		ProductDAO product_dao = new ProductDAO();
		ArrayList<ProductDTO> list = product_dao.product_list();
		
		System.out.println("========================");
		System.out.println("[관리자 모드]");
		System.out.println("[전체 상품 목록]");
		System.out.println("num\tname\t\t\t\tcompany\tprice\tqty");
		
		for(ProductDTO dto : list){
			System.out.print(dto.getNum()+"\t");
			System.out.print(dto.getName()+"\t");
			System.out.print(dto.getCompany()+"\t");
			System.out.print(dto.getPrice()+"\t");
			System.out.println(dto.getQty());
		}//for()
		
		System.out.println("========================");
		System.out.println("1.상품검색\t2.상품추가\t3.상품삭제\t");
		System.out.println("4.재고관리\t5.로그아웃");
		System.out.print("입력: ");
		switch(sc.nextInt()){
			case 1:
				System.out.println("1.상품 이름으로 검색\t2.상품 회사 이름으로 검색");
				System.out.print("입력: ");
				int choose = sc.nextInt();
				if(choose == 1){
					System.out.println("========================");
					System.out.print("검색할 상품의 이름은 무엇입니까? :");
					String name = sc.next();
					ArrayList<ProductDTO> serach_list1 = product_dao.search_product_byProductName(name);	
					System.out.println("num\t\tname\t\tcompany\t\tprice\t\tqty");
					for(ProductDTO dto : serach_list1){
						System.out.print(dto.getNum()+"\t");
						System.out.print(dto.getName()+"\t");
						System.out.print(dto.getCompany()+"\t");
						System.out.print(dto.getPrice()+"\t");
						System.out.println(dto.getQty());
					}//for
				}else if(choose == 2){
					System.out.println("========================");
					System.out.print("검색할 상품의 회사 이름은 무엇입니까? :");
					String company = sc.next();
					ArrayList<ProductDTO> serach_list2 = product_dao.search_product_byCompanyName(company);	
					System.out.println("num\t\tname\t\tcompany\t\tprice\t\tqty");
					for(ProductDTO dto : serach_list2){
						System.out.print(dto.getNum()+"\t");
						System.out.print(dto.getName()+"\t");
						System.out.print(dto.getCompany()+"\t");
						System.out.print(dto.getPrice()+"\t");
						System.out.println(dto.getQty());
					}//for
				}else {
					System.out.println("홈 화면으로 돌아갑니다.");
					System.out.println("다시 로그인 하세요.");
					View.homeV.display();
					break;
				}
				break;
			case 2:
				System.out.println("========================");
				System.out.print("상품을 추가하시겠습니까?(Y/N): ");
				switch(sc.next()){
				case "Y":
					System.out.println("추가할 상품의 정보를 입력해주세요.");
					System.out.print("이름 정보: ");
					String name = sc.next() + sc.nextLine();
					System.out.print("회사 정보: ");
					String company = sc.next() + sc.nextLine();
					System.out.print("가격 정보: ");
					int price = sc.nextInt();
					System.out.print("수량 정보: ");
					int qty = sc.nextInt();
					product_dao.product_add(name, company, price, qty);
					System.out.println("상품을 추가합니다!!!");
					break;
				case "N":
					System.out.println("상품을 추가하지않았습니다...");
					break;
				default :
					System.out.println("홈 화면으로 돌아갑니다.");
					System.out.println("다시 로그인 하세요.");
					View.homeV.display();
					break;
				}//switch()
				break;
			case 3:
				System.out.println("========================");
				System.out.print("상품을 삭제하시겠습니까?(Y/N): ");
				switch(sc.next()){
				case "Y":
					System.out.println("삭제할 상품의 정보를 입력해주세요.");
					System.out.print("이름 정보: ");
					String name = sc.next() + sc.nextLine();
					System.out.print("회사 정보: ");
					String company = sc.next() + sc.nextLine();
					System.out.print("가격 정보: ");
					int price = sc.nextInt();
					product_dao.product_delete(name, company, price);
					System.out.println("상품을 삭제합니다!!!");
					break;
				case "N":
					System.out.println("상품을 삭제하지않았습니다...");
					break;
				default :
					System.out.println("홈 화면으로 돌아갑니다.");
					System.out.println("다시 로그인 하세요.");
					View.homeV.display();
					break;
				}//switch()
				break;
			case 4:
				System.out.println("========================");
				System.out.println("4.재고 관리");
				System.out.println("========================");
				System.out.println("1.재고 추가\t2.재고 차감");
				System.out.print("입력: ");
				int stock_menu = sc.nextInt();
				switch(stock_menu){
					case 1:
						System.out.print("추가할 상품 이름: ");
						String product_name_plus = sc.next() + sc.nextLine();
						System.out.print("추가할 재고 양: ");
						int product_qty_plus = sc.nextInt();
						product_dao.stock_mgt_plus(product_name_plus,product_qty_plus);
						break;
					case 2:
						System.out.print("차감할 상품 이름: ");
						String product_name_minus = sc.next() + sc.nextLine();
						System.out.print("차감할 재고 양: ");
						int product_qty_minus = sc.nextInt();
						product_dao.stock_mgt_minus(product_name_minus,product_qty_minus);
						break;
				}
				break;
			case 5:
				System.out.println("========================");
				System.out.println("5.로그아웃");
				System.out.print("로그아웃 하시겠습니까?(Y): ");
				switch(sc.next()){
					case "Y":
						System.out.println("시스템을 종료합니다...");
						System.exit(0);
						break;
						
					default :
						System.out.println("홈 화면으로 돌아갑니다.");
						System.out.println("다시 로그인 하세요.");
						View.homeV.display();
						break;
				}//switch()
				break;
		}
	}//ad_display()
}
