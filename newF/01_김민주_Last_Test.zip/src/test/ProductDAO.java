package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	//DB 연결 처리
	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn
			= DriverManager.getConnection(
					"jdbc:oracle:thin:@211.223.59.99:1521:xe", "smart01", "0000");
		}catch(Exception e) {
			System.out.println("DB 연결 실패");
			System.out.println(e.getMessage());
		}
	}//connect()
	
	//전체 상품 목록 조회
	public ArrayList<ProductDTO> product_list() {
		//product 정보를 담을 변수 선언
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		
		//DB연결
		connect();
		
		String sql = "select * from tbl_java_product order by 1";
		try {
			ps = conn.prepareStatement(sql);
			// 쿼리문 실행
			rs = ps.executeQuery();
			while(rs.next()){	//커서 이동되면
				//product 정보를 담는 처리 - DTO(데이터 담기)
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				
				list.add(dto);
				
			}//while()
		} catch (Exception e) {
			System.out.println("전체 상품 목록 조회에서 에러 발생");
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
		return list;
	}//product_list()	
	
	//해당 상품 조회
	public ArrayList<ProductDTO> product_sth(int num) {
		//product 정보를 담을 변수 선언
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
				
		//DB연결
		connect();
		
		String sql = "select * "
				+ "from tbl_java_product "
				+ "where num = ?";
		try {
			ps = conn.prepareStatement(sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setInt(1, num);
						
			// 쿼리문 실행
			rs = ps.executeQuery();
			while(rs.next()){	//커서 이동되면
				//product 정보를 담는 처리 - DTO(데이터 담기)
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				
				list.add(dto);
				
			}//while()
		} catch (Exception e) {
			System.out.println("해당 상품 조회에서 에러 발생");
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
		return list;
	}//product_sth()
	
	// 해당 상품 가격 조회
	public ProductDTO product_price(int num){
		//Product정보를 담을 변수 선언
		ProductDTO dto = null;
		
		//DB연결
		connect();
		
		String select_sql =  "select price "
				+ "from tbl_java_product "
				+ "where num = ?";
		try {
			ps = conn.prepareStatement(select_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setInt(1, num);
			
			// 쿼리문 실행
			rs = ps.executeQuery();
			if(rs.next()){	//커서 이동되면
				//DTO(데이터 담기)
				dto = new ProductDTO();
				dto.setPrice(rs.getInt("price"));
			}//if()
		} catch (SQLException e) {
			System.out.println("해당 상품 가격 조회에서 에러 발생");
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
		return dto;
	}//product_price()
	
	
	// 해당 상품 재고 조회
	public ProductDTO product_qty(int num){
		//Product정보를 담을 변수 선언
		ProductDTO dto = null;
		
		//DB연결
		connect();
		
		String select_sql =  "select qty "
				+ "from tbl_java_product "
				+ "where num = ?";
		
		try {
			ps = conn.prepareStatement(select_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setInt(1, num);
			
			// 쿼리문 실행
			rs = ps.executeQuery();
			if(rs.next()){	//커서 이동되면
				//DTO(데이터 담기)
				dto = new ProductDTO();
				dto.setQty(rs.getInt("qty"));
			}//if()
		} catch (SQLException e) {
			System.out.println("해당 상품 재고 조회에서 에러 발생");
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
				
		return dto;
	}//recent_qty()
	
	// 해당 상품 구매 - update	
	public void purchase_product(String id, int product_num){			
		//DB연결
		connect();
		
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e2) {
			System.out.println("setAutoCommit(false) Error");
			System.out.println(e2.getMessage());
		}
		
		//[1] 해당 상품의 재고를 -1만큼 감소시킨다.
		String update_sql1 = "update tbl_java_product "
				+ "set qty = qty -1 "
				+ "where num = ?";
		//[2] 해당 유저의 돈을 상품의 가격만큼 감소시킨다.
		String update_sql2 = "update tbl_java_user "
							+ "set money = money - (select price "
												+ "from tbl_java_product "
												+ "where num = ?) "
							+ "where id = ?";
		try {
			//[1] 해당 상품의 재고를 -1만큼 감소시킨다.
			ps = conn.prepareStatement(update_sql1);
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setInt(1, product_num);
			// 쿼리문 실행
			ps.executeUpdate();
			// 커밋
			conn.commit();
			
			//[2] 해당 유저의 돈을 제픔의 가격만큼 감소시킨다.
			ps = conn.prepareStatement(update_sql2);
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setInt(1, product_num);
			ps.setString(2,id);
			// 쿼리문 실행
			ps.executeUpdate();
			// 커밋
			conn.commit();
		} catch (Exception e) {
			System.out.println("해당 상품 구매에서 에러 발생");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.println("Update Rollback!!!");
				System.out.println(e1.getMessage());
			}//try-catch
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
	}//update_money()
	
	//1.상품 검색 - 상품 이름으로
	public ArrayList<ProductDTO> search_product_byProductName(String name){
		//Product정보를 담을 변수 선언
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		
		//DB연결
		connect();
		
		String select_sql =  "select * "
							+ "from tbl_java_product "
							+ "where name like ? ";
		try {
			ps = conn.prepareStatement(select_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setString(1, "%"+name+"%");
						
			// 쿼리문 실행
			rs = ps.executeQuery();
			while(rs.next()){	//커서 이동되면
				//product 정보를 담는 처리 - DTO(데이터 담기)
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				
				list.add(dto);
			}//while()
		} catch (Exception e) {
			System.out.println("1.상품 검색 - 상품 이름으로에서 에러 발생");
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
		
		return list;
	}//search_product()
	
	//1.상품 검색 - 회사 이름으로
	public ArrayList<ProductDTO> search_product_byCompanyName(String company){
		//Product정보를 담을 변수 선언
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		
		//DB연결
		connect();
		
		String select_sql =  "select * "
							+ "from tbl_java_product "
							+ "where company like ? ";
		try {
			ps = conn.prepareStatement(select_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setString(1, "%"+company+"%");
						
			// 쿼리문 실행
			rs = ps.executeQuery();
			while(rs.next()){	//커서 이동되면
				//product 정보를 담는 처리 - DTO(데이터 담기)
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				
				list.add(dto);
			}//while()
		} catch (Exception e) {
			System.out.println("1.상품 검색 - 회사 이름으로에서 에러 발생");
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
		
		return list;
	}//search_product()
	
	//2.상품 추가
	public void product_add(String name,String company,int price,int qty){
		//DB연결
		connect();
				
		String insert_sql =  "insert into tbl_java_product "
							+ "values(tjp_seq.nextval,?,?,?,?)";
		
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e2) {
			System.out.println("setAutoCommit(false) Error");
			System.out.println(e2.getMessage());
		}
		try {
			ps = conn.prepareStatement(insert_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setString(1, name);
			ps.setString(2, company);
			ps.setInt(3, price);
			ps.setInt(4, qty);
						
			// 쿼리문 실행
			ps.executeUpdate();
			/// 커밋
			conn.commit();
		} catch (Exception e) {
			System.out.println("2.상품 추가에서 에러 발생");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.println("Insert Rollback!!!");
				System.out.println(e1.getMessage());
			}
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
	}//product_add()
	
	//3.상품 삭제
	public void product_delete(String name,String company, int price){
		//DB연결
		connect();
				
		String delete_sql =  "delete tbl_java_product "
							+ "where name = ? "
							+ "and company = ? "
							+ "and price = ?";
		
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e2) {
			System.out.println("setAutoCommit(false) Error");
			System.out.println(e2.getMessage());
		}
		try {
			ps = conn.prepareStatement(delete_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setString(1, name);
			ps.setString(2, company);
			ps.setInt(3, price);
						
			// 쿼리문 실행
			rs = ps.executeQuery();
			/// 커밋
			conn.commit();
		} catch (Exception e) {
			System.out.println("3.상품 삭제에서 에러 발생");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.println("Insert Rollback!!!");
				System.out.println(e1.getMessage());
			}
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
	}//product_delete()

	//4.재고 관리 - 1. 재고 추가
	public void stock_mgt_plus(String product_name, int product_qty){
		//DB연결
		connect();
				
		String update_sql = "update tbl_java_product "
							+ "set qty = qty + ? "
							+ "where name = ?";
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e2) {
			System.out.println("setAutoCommit(false) Error");
			System.out.println(e2.getMessage());
		}
		try {
			ps = conn.prepareStatement(update_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setInt(1, product_qty);
			ps.setString(2, product_name);
						
			// 쿼리문 실행
			rs = ps.executeQuery();
			/// 커밋
			conn.commit();
		} catch (Exception e) {
			System.out.println("4.재고 관리 - 1. 재고 추가에서 에러 발생");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.println("Insert Rollback!!!");
				System.out.println(e1.getMessage());
			}
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
	}//stock_mgt_plus()
	
	//4.재고 관리 - 2. 재고 차감
	public void stock_mgt_minus(String product_name, int product_qty) {
		//DB연결
		connect();
				
		String update_sql = "update tbl_java_product "
							+ "set qty = qty - ? "
							+ "where name = ?";
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e2) {
			System.out.println("setAutoCommit(false) Error");
			System.out.println(e2.getMessage());
		}
		try {
			ps = conn.prepareStatement(update_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setInt(1, product_qty);
			ps.setString(2, product_name);
						
			// 쿼리문 실행
			rs = ps.executeQuery();
			/// 커밋
			conn.commit();
		} catch (Exception e) {
			System.out.println("4.재고 관리 - 2. 재고 차감에서 에러 발생");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.println("Insert Rollback!!!");
				System.out.println(e1.getMessage());
			}
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
	}//stock_mgt_minus()
	
	//자원회수처리
	public void disconnect(){
		if(rs!=null) {
			try {
				rs.close();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
		if(ps!=null) {
			try {
				ps.close();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
	}//disconnect()
}
