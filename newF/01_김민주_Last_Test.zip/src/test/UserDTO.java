package test;

public class UserDTO {
	//DB의 Table의 column명을 기준으로 필드를 선언한다.
	private String id, pw, name, admin, email;
	private int money;
	
	//필드에 데이터를 담는 처리, setter 메소드
	//필드를 private로 지정했기 때문에 필요에 따라 getter,setter 사용
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdmin() {
		return admin;
	}
	public void setAdmin(String admin) {
		this.admin = admin;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
}
