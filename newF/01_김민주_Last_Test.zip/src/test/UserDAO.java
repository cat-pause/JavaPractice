package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;

	//DB 연결 처리
	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn
			= DriverManager.getConnection(
					"jdbc:oracle:thin:@211.223.59.99:1521:xe", "smart01", "0000");
		}catch(Exception e) {
			System.out.println("DB 연결 실패");
			System.out.println(e.getMessage());
		}
	}//connect()
	
	//로그인 확인
	public UserDTO user_check(String id, String pw){
		//User정보를 담을 변수 선언
		UserDTO dto = null;
		
		//DB연결
		connect();
		
		//입력한 아이디와 비밀번호 확인하여 해당 유저 정보 반환
		String select_sql =  "select * "
				+ "from tbl_java_user "
				+ "where id = ? "
				+ "and pw = ? ";
		
		try {
			ps = conn.prepareStatement(select_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setString(1, id);
			ps.setString(2, pw);
			
			// 쿼리문 실행
			rs = ps.executeQuery();
			if(rs.next()){	//커서 이동되면
				//DTO(데이터 담기)
				dto = new UserDTO();
				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setAdmin(rs.getString("admin"));
				dto.setEmail(rs.getString("email"));
				dto.setMoney(rs.getInt("money"));
			}//if()
		} catch (SQLException e) {
			System.out.println("로그인 확인에서 에러 발생");
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
		
		return dto;
	}//User_check()
	
	// 보유 금액 갱신 - update
	public void update_money(int input_price, String id){
		//int cnt = 0;
		//DB연결
		connect();
		
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e2) {
			System.out.println("setAutoCommit(false) Error");
			System.out.println(e2.getMessage());
		}
		String update_sql ="update tbl_java_user "
				+ "set money = money + ? "
				+ "where id = ?";
		try {
			ps = conn.prepareStatement(update_sql);
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setInt(1, input_price);
			ps.setString(2, id);
			
			// 쿼리문 실행
			ps.executeUpdate();
			//cnt = ps.executeUpdate();
			//System.out.println(cnt + "행이 변경되었습니다.");
			if(input_price != 0) {
				System.out.println(input_price+"원 입금되었습니다.");
			}
			conn.commit();
		} catch (Exception e) {
			System.out.println("보유 금액 갱신에서 에러 발생");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.println("Update Rollback!!!");
				System.out.println(e1.getMessage());
			}//try-catch
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
	}//update_money()
	
	//보유 금액 확인 - select
	public UserDTO recent_money(String id){
		//User정보를 담을 변수 선언
		UserDTO dto = null;
		
		//DB연결
		connect();
		
		String select_sql =  "select money "
				+ "from tbl_java_user "
				+ "where id = ?";
		
		try {
			ps = conn.prepareStatement(select_sql);
			
			// 준비된 문장의 ?에 값을 담는 처리
			ps.setString(1, id);
			
			// 쿼리문 실행
			rs = ps.executeQuery();
			if(rs.next()){	//커서 이동되면
				//DTO(데이터 담기)
				dto = new UserDTO();
				dto.setMoney(rs.getInt("money"));
			}//if()
		} catch (SQLException e) {
			System.out.println("보유 금액 확인에서 에러 발생");
			System.out.println(e.getMessage());
		} finally {
			//자원회수처리
			disconnect();
		}//try-catch-finally
				
		return dto;
	}//recent_money()
	
	//자원회수처리
	public void disconnect(){
		if(rs!=null) {
			try {
				rs.close();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
		if(ps!=null) {
			try {
				ps.close();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
	}//disconnect()
}
