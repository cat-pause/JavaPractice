package test;

public class ProductDTO {
	//DB의 Table의 column명을 기준으로 필드를 선언한다.
	private int num, price, qty;
	private String name, company;
	
	//필드에 데이터를 담는 처리, setter 메소드
	//필드를 private로 지정했기 때문에 필요에 따라 getter,setter 사용
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
}
