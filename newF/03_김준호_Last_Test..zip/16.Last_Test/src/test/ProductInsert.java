package test;

import java.util.Scanner;

import product.ProductDAO;

public class ProductInsert {
private Scanner sc;
	
	ProductInsert(Scanner sc){
		this.sc = sc;
	}
	
	public void display() {
		boolean integrity_violation;
		ProductDAO dao = new ProductDAO();
		System.out.println("상품 삽입 화면");
		
		System.out.print("숫자 입력 : ");
		int num = sc.nextInt();
		
		sc.nextLine();//개행문자 제거용
		
		System.out.print("이름 입력 : ");
		String name = sc.nextLine();
		
		System.out.print("출판사 입력 : ");
		String company = sc.nextLine();
				
		System.out.print("가격 입력 : ");
		int price = sc.nextInt();
		
		System.out.print("수량 입력 : ");
		int qty = sc.nextInt();
		
		integrity_violation = dao.product_insert(num, name, company, price, qty);
		
		if(integrity_violation == false) {
			System.out.println("상품 삽입 완료");
		}else if(integrity_violation == true){
			System.out.println("무결성 제약조건에 위배됩니다");
		}
	}
}
