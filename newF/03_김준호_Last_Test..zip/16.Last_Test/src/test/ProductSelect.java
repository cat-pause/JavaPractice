package test;

import java.util.ArrayList;
import java.util.Scanner;

import product.ProductDAO;
import product.ProductDTO;

public class ProductSelect {
	private Scanner sc;
	
	ProductSelect(Scanner sc){
		this.sc = sc;
	}
	
	public void display() {
		ArrayList<ProductDTO> list = null;
		ProductDAO dao = new ProductDAO();
		
		System.out.println("상품 검색 페이지");
		System.out.print("1. 상품명으로 검색\t2. 회사명으로 검색");
		System.out.println("선택 : ");
		
		int menu = sc.nextInt();
		
		if(menu == 1) {
			System.out.print("원하시는 상품명을 입력하세요 : ");
			String product_name = sc.next();
			list = dao.product_select_name(product_name);
			
			for(ProductDTO dto : list) {
				
				System.out.printf("%d\t", dto.getNum());
				System.out.printf("%s\t", dto.getName());
				System.out.printf("%s\t", dto.getCompany());
				System.out.printf("%d\t", dto.getPrice());
				System.out.printf("%d\t\n", dto.getQty());
			}
			
			
		}else if(menu == 2) {
			System.out.print("원하시는 출판사명을 입력하세요 : ");
			String company_name = sc.next();
			list = dao.product_select_company(company_name);
			
			for(ProductDTO dto : list) {
				
				System.out.printf("%d\t", dto.getNum());
				System.out.printf("%s\t", dto.getName());
				System.out.printf("%s\t", dto.getCompany());
				System.out.printf("%d\t", dto.getPrice());
				System.out.printf("%d\t\n", dto.getQty());
			}
		}
	}
}
