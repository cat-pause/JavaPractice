package test;

import java.util.Scanner;

import product.ProductDAO;

public class ProductDelete {
	private Scanner sc;
	
	ProductDelete(Scanner sc){
		this.sc = sc;
	}
	
	public void display() {
		boolean data_exist;
		ProductDAO dao = new ProductDAO();
		System.out.println("상품 삭제 페이지");
		View.product_list.display();
		
		System.out.print("삭제를 원하는 상품의 번호를 입력하세요 : ");
		int del_num = sc.nextInt();
		
		data_exist = dao.product_delete(del_num);
		if(data_exist == true) {
			System.out.println("선택한 번호의 상품을 삭제하였습니다.");
		}else {
			System.out.println("선택한 번호의 상품이 존재하지 않습니다.");
		}
	}

}
