package test;

import java.util.Scanner;

import product.ProductDAO;

public class ProductUpdate {
private Scanner sc;
	
	ProductUpdate(Scanner sc){
		this.sc = sc;
	}
	
	public void display() {
		ProductDAO dao = new ProductDAO();
		
		System.out.println("재고 관리 페이지");
		View.product_list.display();
		
		System.out.print("수정할 상품의 번호를 입력하세요 : ");
		int num = sc.nextInt();
		System.out.print("재고 입력 : ");
		int qty = sc.nextInt();
		
		boolean exist = dao.product_modify(num, qty);
		if(exist == true) {
			System.out.println("재고 수정이 완료되었습니다.");
		}else {
			System.out.println("선택한 번호의 상품이 존재하지 않습니다.");
		}
		
	}
}
