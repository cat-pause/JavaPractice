package test;

public class View {
	static Login login;
	static UserHome userhome;
	static AdminHome adhome;
	
	static ProductList product_list;
	
	static ProductSelect product_selete;
	static ProductDelete product_delete;
	static ProductInsert product_insert;
	static ProductUpdate product_update;
	
	static UserMoney user_money;
	static UserOrder user_order;
}
