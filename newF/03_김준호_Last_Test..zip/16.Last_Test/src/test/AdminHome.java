package test;

import java.util.Scanner;

public class AdminHome {
	private Scanner sc;
	
	public AdminHome(Scanner sc){
		this.sc = sc;
	}
	
	public void display() {
		System.out.println("관리자 홈");
		View.product_list.display();
		
		while(true) {
			
			System.out.println("1.상품검색 2.상품추가 3.상품삭제 4.재고관리 0.로그아웃");
			System.out.print("선택 : ");
			
			int menu = sc.nextInt();
			
			if(menu == 1) {
				//상품 검색 
				View.product_selete.display();
			}
			else if(menu == 2) {
				//상품 추가
				View.product_insert.display();
			}
			else if(menu == 3) {
				//상품 삭제
				View.product_delete.display();
			}
			else if(menu == 4) {
				//재고 관리
				View.product_update.display();
			}
			else if(menu == 0){
				//로그아웃
				System.exit(0);
			}
			else {
				System.out.println("잘못입력하셨습니다. 다시 입력하세요.");
			}
		}
	}
}
