package test;
import java.util.Scanner;

import user.UserDAO;

public class Login {
	private Scanner sc;
	static String id;
	Login(Scanner sc){
		this.sc = sc;
	}
	
	public void display() {
		System.out.println("로그인 화면");
		System.out.print("아이디 입력 : ");
		
		UserDAO dao = new UserDAO();
		String id = sc.next();
		boolean id_ToF = dao.login_id(id);
		
		if(id_ToF == true) {
			System.out.print("비밀번호 입력 : ");
			String pw = sc.next();
			int pw_ToF = dao.login_pw(id, pw);
			if(pw_ToF == 2) {
				//관리자
				System.out.println("관리자 로그인 성공 ");
				View.adhome.display();
			}
			else if(pw_ToF == 1) {
				//회원
				System.out.println("일반회원 로그인 성공");
				View.userhome.display(id);
			}
			else if(pw_ToF == 0) {
				System.out.println("비밀번호가 일치하지 않습니다.");
			}
			
		}else {
			System.out.println("아이디가 일치하지 않거나 존재하지 않습니다.");
		}
		
		
	}
}
