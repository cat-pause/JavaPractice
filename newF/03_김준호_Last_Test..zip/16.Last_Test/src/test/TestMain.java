package test;

import java.util.Scanner;

public class TestMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		View.adhome = new AdminHome(sc);
		View.userhome = new UserHome(sc);
		View.login = new Login(sc);
		
		View.product_list = new ProductList();
		
		View.product_selete = new ProductSelect(sc);
		View.product_delete = new ProductDelete(sc);
		View.product_update = new ProductUpdate(sc);
		View.product_insert = new ProductInsert(sc);
		
		View.user_money = new UserMoney(sc);
		View.user_order = new UserOrder(sc);
		
		View.login.display();
	}
	
	

}
