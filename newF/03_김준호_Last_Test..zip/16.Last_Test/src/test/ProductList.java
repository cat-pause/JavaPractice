package test;

import java.util.ArrayList;

import product.ProductDAO;
import product.ProductDTO;

public class ProductList {

	
	public void display() {
		System.out.println("------------------------상품 목록------------------------");
		
		ProductDAO dao = new ProductDAO();
		ArrayList<ProductDTO> product_list = dao.product_list();
		System.out.println("상품번호\t상품명\t\t\t출판사\t\t가격\t 수량\t");
		for(ProductDTO dto : product_list) {
			System.out.printf("%d \t", dto.getNum());
			System.out.printf("%s \t", dto.getName());
			System.out.printf("%s \t", dto.getCompany());
			System.out.printf("%s \t", dto.getPrice());
			System.out.printf("%d \n", dto.getQty());
		}
		System.out.println("-----------------------------------------------------");
		
	}
	
}
