package product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProductDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	public void connect() {
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@211.223.59.99:1521:xe", "smart03", "0000");
			
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void disconnect() {
		if( rs!=null ) { try{rs.close();}catch(Exception e) {} }		
		if( ps!=null ) { try{ps.close();}catch(Exception e) {} }		
		if( conn!=null ) { try{conn.close();}catch(Exception e) {} }		
	}
	
	//상품목록 조회
	public ArrayList<ProductDTO> product_list() {
		ArrayList<ProductDTO> product_list = new ArrayList<ProductDTO>();
		connect();
		String sql = "select * "
				+ " from tbl_java_product"
				+ "	order by 1";
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				ProductDTO dto = new ProductDTO();
				
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				product_list.add(dto);
			}
			
			
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			disconnect();
		}
		return product_list;
	}
	
	//상품 이름으로 검색 
	public ArrayList<ProductDTO> product_select_name(String product_name) {
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>(); 
		connect();
		String keyword = "%" + product_name + "%";
		
		String sql = "SELECT *"
				+ " FROM tbl_java_product"
				+ " WHERE name LIKE ?"
				+ " order by 1"; 
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, keyword);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				
				list.add(dto);
			}
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		} 
		finally {
			disconnect();
		}
		return list;
		
		
	}
	//상품 회사로 검색
	public ArrayList<ProductDTO> product_select_company(String company_name) {
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		connect();
		String keyword = "%" + company_name + "%";
		String sql = "SELECT *"
				+ " FROM tbl_java_product"
				+ " WHERE company LIKE ? "
				+ " order by 1"; 
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, keyword);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				
				list.add(dto);
			}
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		} 
		finally {
			disconnect();
		}
		return list;
		
	}
	
	//상품 추가
	public boolean product_insert(int num, String name, String company, int price, int qty) {
		boolean integrity_violation = false;
		
		connect();
		
		String sql = "Insert into tbl_java_product"
				+ " values(?,?,?,?,?)";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			ps.setString(2, name);
			ps.setString(3, company);
			ps.setInt(4, price);
			ps.setInt(5, qty);
			rs = ps.executeQuery();
		} 
		catch (Exception e) {
			integrity_violation = true;
		}
		finally {
			disconnect();
		}
		return integrity_violation;
	}
	
	//상품 삭제
	public boolean product_delete(int del_num) {
		boolean data_exist = true;
		connect();
		
		String sql = "Delete"
				+ " From tbl_java_product"
				+ " Where num = ?"; 
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, del_num);
			rs = ps.executeQuery();
			if(!rs.next()){
				data_exist = false;
			}
			
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return data_exist;
	}
	
	//상품 수정
	public boolean product_modify(int num, int qty) {
		boolean data_exist = true;
		connect();
		
		String sql = "update tbl_java_product"
				+ " set qty = ?"
				+ " where num = ?"; 
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(2, num);
			ps.setInt(1, qty);
			rs = ps.executeQuery();
			
			if(!rs.next()) {
				data_exist = false;
			}
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return data_exist;
	}
	
	
}
