package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import product.ProductDTO;


public class UserDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	
	
	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@211.223.59.99:1521:xe", "smart03", "0000");
			
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}	
	}
	
	public void disconnect() {
		if( rs!=null ) { try{rs.close();}catch(Exception e) {} }		
		if( ps!=null ) { try{ps.close();}catch(Exception e) {} }		
		if( conn!=null ) { try{conn.close();}catch(Exception e) {} }		
	}
	
	public boolean login_id(String id) {
		boolean id_ToF= false;
		connect();
		String sql = "select id "
				+ " from tbl_java_user"
				+ " where id = ?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				id_ToF = true;
			}else {
				id_ToF = false;
			}
			
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			disconnect();
		}
		return id_ToF;

	}
	
	public int login_pw(String id, String pw) {
		int pw_ToF = 0;
		
		UserDTO dto = null;
		connect();
		String sql = "select pw, admin"
				+ " from tbl_java_user"
				+ " where id = ?"
				+ " and pw = ?";
		
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, pw);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dto = new UserDTO();
				dto.setAdmin(rs.getString("admin"));
				String admin = dto.getAdmin();
				if(admin.equals("Y")) {
					//System.out.println("----------관리자 로그인----------");
					pw_ToF = 2;
				}
				else if(admin.equals("N")){
					//System.out.println("----------일반회원 로그인----------");
					pw_ToF = 1;
				}
			}
			else {
				//System.out.println("비밀번호가 일치하지 않습니다.");
				pw_ToF = 0;
			}
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			disconnect();
		}
		
		return pw_ToF;
	}
	
	public UserDTO balance_inquiry(String id) {
		UserDTO dto = new UserDTO();
		
		connect();
		String sql = "select *"
				+ " from tbl_java_user"
				+ " where id = ?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dto.setName(rs.getString("name"));
				dto.setMoney(rs.getInt("money"));
			}		
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			disconnect();
		}
		return dto;
	}
	
	public void add_money(String id, int money, int balance) {
		connect();
		
		int update_balance = money + balance;
		
		String sql = "Update tbl_java_user"
				+ " set money = ?"
				+ " where id = ?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, update_balance);
			ps.setString(2, id);
			rs = ps.executeQuery();
			
		
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			disconnect();
		}
	}
	
	public int order_check(String order_id, int order_num, int order_qty) {
		int check = 1;
		ProductDTO pdto = new ProductDTO();
		UserDTO udto = new UserDTO();
		
		connect();
		String sql = "select money, price, qty"
				+ " from tbl_java_user, tbl_java_product"
				+ " where id = ?"
				+ " and num = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, order_id);
			ps.setInt(2, order_num);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				udto.setMoney(rs.getInt("money"));
				pdto.setPrice(rs.getInt("price"));
				pdto.setQty(rs.getInt("qty"));
				
				int balance = udto.getMoney();
				int price = pdto.getPrice();
				int qty = pdto.getQty();
				
				
				if(qty >= order_qty) {
					if(balance >= (price * order_qty)) {
						check = 1;
					}else {
						check = -1;//잔액부족
					}
				}else {
					check = 0;//재고부족
				}
			}else {
				check = -2;
			}
			
			

		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			disconnect();
		}
		return check;
	}
	
	
	public void order(String order_id, int order_num, int order_qty) {
		connect();
		
		String sql = "insert into tbl_java_order"
				+ " values("
				+ "order_squence.nextval, ?, (select name from tbl_java_product where num = ?), ?"
				+ ")";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, order_id);
			ps.setInt(2, order_num);
			ps.setInt(3, order_qty);
			rs = ps.executeQuery();
			
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			disconnect();
		}
	}
	
	public void order_update(String order_id, int order_num, int order_qty) {
		ProductDTO dto = new ProductDTO();

		
		connect();
		//가격조회
		String sql1 = "select price"
				+ " from tbl_java_user, tbl_java_product"
				+ " where id = ?"
				+ " and num = ?";
		//사용자 잔액 차감
		String sql2 = "update tbl_java_user"
				+ " set money = (money - ?)"
				+ " where id = ?";
		//상품 재고 차감
		String sql3 = "update tbl_java_product"
				+ " set qty = qty - ? "
				+ " where num = ?";
		
		try {
			ps = conn.prepareStatement(sql1);
			ps.setString(1, order_id);
			ps.setInt(2, order_num);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dto.setPrice(rs.getInt("price"));
			}
			
			int price = dto.getPrice();
			int AoP = (price * order_qty); //결제금액 Amount of Payment
			
			ps = conn.prepareStatement(sql2);
			ps.setInt(1, AoP);
			ps.setString(2, order_id);
			rs = ps.executeQuery();
			
			ps = conn.prepareStatement(sql3);
			ps.setInt(1, order_qty);
			ps.setInt(2, order_num);
			rs = ps.executeQuery();
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			disconnect();
		}
		
		
	}
	
}
