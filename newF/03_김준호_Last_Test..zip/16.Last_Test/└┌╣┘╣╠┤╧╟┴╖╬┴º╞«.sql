create table tbl_java_user(
    id varchar2(50) not null primary key,
    pw varchar2(50) not null,
    name varchar2(20),
    admin varchar2(1),
    email varchar2(100),
    money number
);

create table tbl_java_product(
    num number not null primary key,
    name varchar2(50),
    company varchar2(50),
    price number,
    qty number
);

create table tbl_java_order(
    order_num number not null primary key,
    id varchar2(50) not null references tbl_java_user(id),
    name varchar2(50) not null,
    qty number
);

insert into tbl_java_user
values(
--    'admin', 'admin', '관리자',  'Y', 'admin@naver.com', 0
--    'user1', 'user1', '사용자', 'N', 'user@naver.com', 100000
    'user2', 'user2', 'ho', 'N', 'ho@gmail.com', 10000
);

insert into tbl_java_product
values(
--    1, '혼자 공부하는 자바', '한빛미디어', 30000, 5
    2, '같이 공부하는 자바', '한울', 10000, 0
);

select num, name, company, price, qty
from tbl_java_product
where name like '%자바%';

SELECT num, name, company, price, qty
FROM tbl_java_product
WHERE name LIKE '%자바%';

commit;


delete from tbl_java_product where num in (7,8);
update tbl_java_product
set qty = 10
where num = 2;

create sequence order_squence;

insert into tbl_java_order
values(
    order_squence.nextval, 'user1', (select name from tbl_java_product where num =2), 2
);

update tbl_java_user
set money = (money - 5000)
where id = 'user1';

update tbl_java_product
set qty = (qty-2)
where num = 1;

select * from tbl_java_user order by 1;
select * from tbl_java_product order by 1;
select * from tbl_java_order;

select name from tbl_java_product where num =2;


select money, price, qty 
from tbl_java_user , tbl_java_product
where id = 'user1'
and num = 3;

select price, qty from tbl_java_product where num = 1;