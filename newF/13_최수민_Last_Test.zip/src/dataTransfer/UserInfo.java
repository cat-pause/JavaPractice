package dataTransfer;

public class UserInfo {
	private static UserDTO userinfo;

	public static UserDTO getUserinfo() {
		return userinfo;
	}

	public static void setUserinfo(UserDTO userinfo) {
		UserInfo.userinfo = userinfo;
	}
}
