package dataAcess;

import org.apache.commons.mail.HtmlEmail;

public class EmailSender {
	private String emailAddress, senderName, emailPassword;
	public EmailSender(String emailAddress, String senderName, String emailPassword){
		this.emailAddress = emailAddress;
		this.senderName = senderName;
		this.emailPassword = emailPassword;
	}
	
	public boolean sendHtml(String email, String name, String validNum) {
		HtmlEmail mail = new HtmlEmail();
		mail.setCharset("utf-8"); 
		//mail.setDebug(true); 

		// 메일 서버 지정
		mail.setHostName("smtp.office365.com");

		mail.setAuthentication(emailAddress, emailPassword);
		mail.setSmtpPort(587);
		// mail.setSSLOnConnect(true);
		mail.setStartTLSEnabled(true);
		try {
			mail.setFrom(emailAddress, senderName);
			mail.addTo(email, name);
			
			mail.setSubject("회원관리 비밀번호 변경 확인 메일");
			StringBuffer msg = new StringBuffer();
			msg.append("<html>");
			msg.append("<body>");
			msg.append("<h2>").append(name).append("님의 비밀번호 변경 확인 코드입니다.</h2>");
			msg.append("<div>확인 코드 : "+ validNum +"</div>");
			msg.append("</body>");
			msg.append("</html>");
			mail.setHtmlMsg( msg.toString() );
			
			mail.send();			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		return true;
	}

}
