package dataAcess;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import dataTransfer.UserDTO;
import dataTransfer.UserInfo;

public class UserDAO extends SuperDAO {

	private UserDTO dto;
	private String sql;

	public String whoAreU(String id) {
		String name = null;
		connect();
		String sql = "SELECT name" + " FROM tbl_java_user" + " WHERE id=?";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			if (rs.next())
				name = rs.getString("name");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return name;
	}

	public boolean emailValid(String email) {
		connect();
		String sql = "SELECT id" + " FROM tbl_java_user" + " WHERE email=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, email);
			rs = ps.executeQuery();

			if (!rs.next()) {
				return true;
				// 없으면 true
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return false;// 있으면 false

	}

	public String randValid() {
		Random random = new Random(System.currentTimeMillis());

		int range = (int) Math.pow(10, 6);
		int trim = (int) Math.pow(10, 6 - 1);
		int result = random.nextInt(range) + trim;

		if (result > range) {
			result = result - trim;
		}

		return String.valueOf(result);
	}

	public void changePassword(String id, String pw) {

		connect();
		String sql = "UPDATE tbl_java_user" + " SET pw=?" + " WHERE id=?";
		try {

			ps = conn.prepareStatement(sql);
			ps.setString(1, pw);
			ps.setString(2, id);
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}

	}

	public int deposit(int money, UserDTO dto) {
		int total = 0;
		int remain = UserInfo.getUserinfo().getMoney();

		connect();
		String sql = "UPDATE tbl_java_user" + " SET money=?" + " WHERE id=?";
		try {
			remain += money;
			ps = conn.prepareStatement(sql);
			ps.setInt(1, remain);
			ps.setString(2, dto.getUserId());
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		refresh();
		total = UserInfo.getUserinfo().getMoney();
		return total;
	}

	// 로그인 쿼리
	public UserDTO login(String userId, String userPw) {
		connect();
		String sql = "SELECT *" + " FROM tbl_java_user" + " WHERE id=? AND pw =?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, userId);
			ps.setString(2, userPw);
			rs = ps.executeQuery();
			while (rs.next()) {
				dto = new UserDTO();
				dto.setUserId(rs.getString("id"));
				dto.setUserPw(rs.getString("pw"));
				dto.setIsAdmin(rs.getString("admin"));
				dto.setName(rs.getString("name"));
				dto.setEmail(rs.getString("email"));
				dto.setMoney(rs.getInt("money"));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return dto;

	}

	public boolean idValid(String id) {
		connect();
		String sql = "SELECT id" + " FROM tbl_java_user" + " WHERE id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();

			if (!rs.next()) {
				return true;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return false;

	}

	public int join(String id, String pw, String name, String email) {
		int count = 0;

		connect();

		String sql = "INSERT INTO tbl_java_user VALUES (? , ?, ?, 'N' , ?,0)";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, pw);
			ps.setString(3, name);
			ps.setString(4, email);
			count = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return count;
	}

	public ArrayList<UserDTO> memberList() {
		ArrayList<UserDTO> list = new ArrayList<UserDTO>();
		connect();
		sql = "SELECT *" + " FROM tbl_java_user" + " ORDER BY id";
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				UserDTO dto = new UserDTO();
				dto.setUserId(rs.getString("id"));
				dto.setUserPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setEmail(rs.getString("email"));
				dto.setIsAdmin(rs.getString("admin"));
				list.add(dto);

			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return list;
	}

	public int UpdateMember(String id, String pw, String name, String email, int money, String admin) {
		connect();
		sql = "UPDATE tbl_java_user SET pw=?,name=?,email=?,money=?,admin=upper(?) WHERE id=?";
		int count = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, pw);
			ps.setString(2, name);
			ps.setString(3, email);
			ps.setInt(4, money);
			ps.setString(5, admin);
			ps.setString(6, id);
			count = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}

		return count;
	}

	public int DeleteMember(String id) {
		int count = 0;
		connect();
		sql = "DELETE FROM tbl_java_user" + "		WHERE id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			count = ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return count;
	}

	public UserDTO memberInfo(String userId) {
		connect();
		String sql = "SELECT *" + " FROM tbl_java_user" + " WHERE id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, userId);
			rs = ps.executeQuery();
			while (rs.next()) {
				dto = new UserDTO();
				dto.setUserId(rs.getString("id"));
				dto.setUserPw(rs.getString("pw"));
				dto.setIsAdmin(rs.getString("admin"));
				dto.setName(rs.getString("name"));
				dto.setEmail(rs.getString("email"));
				dto.setMoney(rs.getInt("money"));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return dto;

	}

	public void refresh() {
		connect();
		String sql = "SELECT *" + " FROM tbl_java_user" + " WHERE id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, UserInfo.getUserinfo().getUserId());
			rs = ps.executeQuery();
			while (rs.next()) {
				dto = new UserDTO();
				dto.setUserId(rs.getString("id"));
				dto.setUserPw(rs.getString("pw"));
				dto.setIsAdmin(rs.getString("admin"));
				dto.setName(rs.getString("name"));
				dto.setEmail(rs.getString("email"));
				dto.setMoney(rs.getInt("money"));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
			UserInfo.setUserinfo(dto);
		}
	}
}
