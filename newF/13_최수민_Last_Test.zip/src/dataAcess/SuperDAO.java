package dataAcess;

import java.sql.*;

public class SuperDAO {

	Connection conn;
	PreparedStatement ps;
	ResultSet rs;
	
	public SuperDAO() {
		super();
	}

	public void disconnect() {
		if (rs != null) { try {rs.close();} catch (Exception e) {}}
		if (ps != null) { try {ps.close();} catch (Exception e) {}}
		if (conn != null) { try {conn.close();} catch (Exception e){}}
	}

	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@211.223.59.99:1521:xe","smart13","0000");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}