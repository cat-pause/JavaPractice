package dataAcess;


import java.sql.SQLException;
import java.util.ArrayList;

import dataTransfer.ProductDTO;
import dataTransfer.UserDTO;

public class ProductDAO extends SuperDAO{

	private String sql;
	
	public int orderProduct(UserDTO dto, int num, int qty) {
//수량여러개 주문
		ProductDTO product = searchNum(num);
		int totalMoney= qty * product.getPrice();
		
		if(qty>product.getQty()) {
			return 0;   //수량 부족할 경우 0 리턴
		}		

		if (totalMoney > dto.getMoney()) {
			return -1;	//잔액부족 -1 리턴
		} else {
			//돈있으니까 잔액에서 가격 만큼 차감하는 쿼리 입금에 -줘서 재활용
			new UserDAO().deposit(-totalMoney, dto);
			
			//수량 개수만큼 없애는 쿼리
			connect();
			String sql = "UPDATE tbl_java_product"
					+ " SET qty=?"
					+ " WHERE num=?";
			int remainQ = product.getQty()-qty;
			
			try {
				ps = conn.prepareStatement(sql);
				ps.setInt(1, remainQ);
				ps.setInt(2, num);
				ps.executeQuery();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}finally {
				disconnect();
			}
			return 1;
		}
	}
	
		
	// 상품 전체 리스트 가져오기
	public ArrayList<ProductDTO> productList() {
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		connect();
		sql = "SELECT *"
				+ " FROM tbl_java_product"
				+ " ORDER BY num";

		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while ( rs.next() ) {
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setProductName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));

				list.add(dto);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}
		return list;
	}

	public ArrayList<ProductDTO> searchProduct(String product) {
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();

		connect();
		sql = "SELECT *"
				+ " FROM tbl_java_product"
				+ " WHERE name LIKE '%'||?||'%' ORDER BY num";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, product);
			rs = ps.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setProductName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				list.add(dto);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}

		return list;
	}

	public ArrayList<ProductDTO> searchCompany(String company) {
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();

		connect();
		sql = "SELECT *"
				+ " FROM tbl_java_product"
				+ " WHERE company"
				+ " LIKE '%'||?||'%' ORDER BY num";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, company);
			rs = ps.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setNum(rs.getInt("num"));
				dto.setProductName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
				list.add(dto);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			disconnect();
		}

		return list;
	}
	
	public ProductDTO searchNum(int num) {
		ProductDTO dto = new ProductDTO();
		connect();
		sql = "SELECT *"
				+ " FROM tbl_java_product"
				+ " WHERE num =?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			rs = ps.executeQuery();

			if (rs.next()) {
				dto.setNum(rs.getInt("num"));
				dto.setProductName(rs.getString("name"));
				dto.setCompany(rs.getString("company"));
				dto.setPrice(rs.getInt("price"));
				dto.setQty(rs.getInt("qty"));
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return dto;
	}
	
	
	public int howMany(int num) {
		int remain=0;
		connect();
		sql = "SELECT qty"
				+ " FROM tbl_java_product"
				+ " WHERE num =?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			rs = ps.executeQuery();

			if (rs.next()) {
				remain = rs.getInt("qty");
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return remain;
	}
	public int insertProduct(String productName, String company, int price, int qty) {
		int count =0;
		connect();
		sql = "INSERT INTO tbl_java_product"
				+ " VALUES (product_seq.nextval,?,?,?,?)";
		try {
			ps = conn.prepareStatement(sql);
		
			ps.setString(1, productName);
			ps.setString(2, company);
			ps.setInt(3, price);
			ps.setInt(4, qty);
			count = ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return count;
	}
	


	public int updateProduct(int num, int qty) {
		int count = 0;
		connect();
		sql = "UPDATE tbl_java_product SET qty=? WHERE num=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, qty);
			ps.setInt(2, num);
			count =ps.executeUpdate();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return count;
	}

	public int deleteProduct(int num) {
		int count=0;
		connect();
		sql = "DELETE FROM tbl_java_product"
				+ "		WHERE num=?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			count =ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return count;
	}	
}
