package view;

import java.util.Scanner;

public class TestMain {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		View.index = new Index(scan);
		View.pManage = new ProductManage(scan);
		View.mManage = new MemberManage(scan);
		View.index.display(); 
		scan.close();
	}
}
