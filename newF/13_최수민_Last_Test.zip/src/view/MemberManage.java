package view;

import java.util.ArrayList;
import java.util.Scanner;

import dataAcess.EmailSender;
import dataAcess.UserDAO;
import dataTransfer.UserDTO;
import dataTransfer.UserInfo;

public class MemberManage {
	Scanner scan;

	public MemberManage(Scanner scan) {
		this.scan = scan;
	}
	
	public void display() {
		System.out.println("---------회원 관리---------");
		System.out.println("1. 회원 목록    2. 회원 정보 변경     3. 회원 삭제     0. 관리자페이지");
		System.out.print("메뉴 선택 : ");
		int select = Integer.parseInt(scan.next());
		
		switch (select) {
		case 1:
			memberList();
			display();
			break;
		case 2:
			manage();
			display();
			break;
		case 3:
			delete();
			display();
			break;

		default:
			View.pManage.display();;
			break;
		}
	}
	
	public void memberList() {
		UserDAO dao = new UserDAO();

		ArrayList<UserDTO> list = dao.memberList();
		System.out.println("----------------------------- 회원 목록 -------------------------------");
		System.out.println("ID \t패스워드 \t 이름 \t EMAIL \t\t\t\t 잔액 \t관리자");
		System.out.println("---------------------------------------------------------------------");

		for (UserDTO dto : list) {
			System.out.printf("%s\t%s\t%s\t%-20s\t\t%d\t  %s\n", dto.getUserId(),dto.getUserPw(), dto.getName(), dto.getEmail(), dto.getMoney(),
					dto.getIsAdmin());
		}
		System.out.println("---------------------------------------------------------------------");
	}
	
	public void manage() {
		System.out.println("---------회원 정보 변경---------");
		scan.nextLine();
		System.out.print("회원 아이디 입력 : ");
		String id = scan.nextLine();
		UserDTO dto = new UserDAO().memberInfo(id);
		if ( ! new UserDAO().idValid(id) ) {
			System.out.print("회원 패스워드 입력 "+ dto.getUserPw() +" -> ");
			String pw = scan.nextLine();
			System.out.print("회원 이름 입력 " + dto.getName() + " -> ");
			String name = scan.nextLine();
			System.out.print("회원 이메일 입력 "+ dto.getEmail() + " -> ");
			String email = scan.nextLine();
			System.out.print("회원 잔액 입력 " + dto.getMoney() + " -> ");
			int money = scan.nextInt();
			scan.nextLine();
			System.out.print("관리자 권한 입력 (Y or N): ");
			String admin = scan.nextLine();
			new UserDAO().UpdateMember(id,pw,name,email,money,admin);

		}else {
			System.out.println("아이디를 확인하세요.");
		}

	}

	public void delete() {
		System.out.println("---------회원 삭제---------");
		scan.nextLine();
		System.out.print("회원 아이디 입력 : ");
		String id = scan.nextLine();
		int done = new UserDAO().DeleteMember(id);
		if (done == 1) {
			System.out.println("삭제 성공!");
		} else {
			System.out.println("삭제 실패!");
		}
		
	}
	
	public void join() {
		System.out.println("----------------------------회원가입 페이지----------------------------");
		scan.nextLine();
		System.out.printf("\n아이디 입력 : ");
		String id = scan.nextLine();
		UserDAO dao = new UserDAO();
		if ( dao.idValid(id) == false ) {
			System.out.println("\n중복된 아이디 입니다. 아이디를 확인해주세요.");
		} else {
			System.out.printf("\n패스워드 입력 : ");
			String pw = scan.nextLine();
			
			System.out.printf("\n이름 입력 : ");
			String name = scan.nextLine();
			
			System.out.printf("\n이메일 입력 : ");		
			String email = scan.nextLine();
			int success = dao.join(id, pw, name, email);
			if(success == 1 ) {
				System.out.printf("\n가입 성공!\n");
			}else {
				System.out.printf("\n가입 실패! 관리자에게 문의하세요!\n");
			}
			
		}
	}
	public void findPw() {
		scan.nextLine();
		UserDAO dao = new UserDAO();
		System.out.println("----------------------------비밀번호찾기----------------------------");
		System.out.print("찾으시려는 아이디 : ");

		String id = scan.nextLine();

		System.out.print("메일 주소 : ");
		String email = scan.nextLine();

		if (dao.idValid(id) || dao.emailValid(email)) {
			System.out.println("아이디나 이메일을 확인하세요.");
			display();
		}

		String valid = dao.randValid();

		EmailSender sender = new EmailSender("tnalss@hotmail.com", "관리자", "0000");

		if (sender.sendHtml(email, dao.whoAreU(id), valid)) {

			System.out.println("이메일이 전송되었습니다.");
			System.out.print("확인코드 6자리 입력 : ");
			String userInput = scan.nextLine();

			if (valid.equals(userInput)) {
				System.out.print("변경할 패스워드 입력 : ");

				String pw = scan.nextLine();
				dao.changePassword(id, pw);

			} else {
				System.out.println("확인코드가 맞지 않네요");
			}
		} else {
			System.out.println("메일 전송 실패");
			System.out.println("MemberManage 클래스의 findPw() 비밀번호 체크");
		}
	}
	public void login() {
		System.out.print("아이디 : ");
		String userId = scan.next();
		System.out.print("패스워드 : ");
		String userPw = scan.next();
		
		boolean validId = new UserDAO().idValid(userId);
		if (! validId) {
	
			UserDTO dto = new UserDAO().login(userId, userPw);
			
			if (dto != null) {
				UserInfo.setUserinfo(dto);
				View.pManage.display();
			}else {
				System.out.println("패스워드를 확인하세요.");
			}
		
		} else {
			System.out.println("로그인 실패.. 아이디를 확인하세요..\n\n");
			View.index.display();

		}
	}
	public void deposit(Scanner scan) {
		int money=0;
		
		System.out.print("입금 하실 금액 : ");
		money=scan.nextInt();
		if(money <= 0) {
			System.out.println("1원 이상 입금하셔야합니다.");
			deposit(scan);
		}
		new UserDAO().deposit(money,UserInfo.getUserinfo());
	}

}
