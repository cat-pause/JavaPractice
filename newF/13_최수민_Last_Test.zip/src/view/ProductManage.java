package view;

import java.util.ArrayList;
import java.util.Scanner;

import dataAcess.ProductDAO;
import dataAcess.UserDAO;
import dataTransfer.ProductDTO;
import dataTransfer.UserDTO;
import dataTransfer.UserInfo;

public class ProductManage {
	Scanner scan;

	public ProductManage(Scanner scan) {
		this.scan = scan;
	}
	public void display() {
		list();
		if (UserInfo.getUserinfo().getIsAdmin().equals("Y")) {
			adminDisplay(scan);
		} else {
			customerDisplay(scan);
		}

	}
	public void list() {
		ArrayList<ProductDTO> list = new ProductDAO().productList();
		System.out.println("----------------------------전체 상품 리스트------------------------------");
		System.out.println("품번 \t 물품명 \t\t\t 제작회사 \t\t 가격 \t 수량");
		System.out.println("---------------------------------------------------------------------");

		for (ProductDTO dto : list) {
			if (dto.getQty() == 0) {
				System.out.printf("%d \t %-15s \t %-10s \t %d \t [품절]\n", dto.getNum(), dto.getProductName(),
						dto.getCompany(), dto.getPrice());

			} else {
				System.out.printf("%d \t %-15s \t %-10s \t %d \t  %d\n", dto.getNum(), dto.getProductName(),
						dto.getCompany(), dto.getPrice(), dto.getQty());
			}
		}
		System.out.println("---------------------------------------------------------------------");
	}

	public void adminDisplay(Scanner scan) {
	
		System.out.println("관리자 페이지");
		System.out.printf("1. 상품 검색  2. 상품 추가  3. 상품 삭제 4. 재고 관리  5. 회원관리  6. 로그아웃  0. 종료\n");
		System.out.print("선택: ");

		int menu = scan.nextInt();

		switch (menu) {
		case 1:
			search();
			adminDisplay(scan);
			break;
		case 2:
			// 상품추가 insert
			View.pManage.insertProduct();
			display();
			break;
		case 3:
			// 상품삭제 delete
			View.pManage.deleteProduct();
			display();
			break;

		case 4:
			// 재고관리 update
			View.pManage.updateProduct();
			display();
			break;

		case 5:
			View.mManage.display();

			break;

		case 6:
			// 로그아웃//메인페이지
			UserInfo.setUserinfo(null);
			View.index.display();
			break;
		default:
			System.exit(0);
			break;
		}

	}

	public void customerDisplay(Scanner scan) {
		UserDAO dao= new UserDAO();
		dao.refresh();
		System.out.println(UserInfo.getUserinfo().getName() + "님                   현재 잔액 : "
				+ UserInfo.getUserinfo().getMoney() + " 원");

		System.out.println("1. 금액 입력 2. 상품주문 3. 상품검색 0. 로그아웃");
		System.out.print("선택: ");

		int menu = scan.nextInt();

		switch (menu) {
		case 1:
			// 금액입력//입금처리
			View.mManage.deposit(scan);
			display();
			break;
		case 2:
			// 상품주문
			View.pManage.order(scan);
			display();
			break;
		case 3:
			search();
			customerDisplay(scan);
			break;

		default:
			UserInfo.setUserinfo(null);
			View.index.display();
			break;
		}
	}
	public void search() {

		System.out.println("---------상품 검색-----------");
		System.out.println("1. 이름으로 검색   2. 회사로 검색  3. 이전 페이지  0. 종료");
		System.out.print("메뉴 선택 : ");
		int menu = scan.nextInt();
		
		switch (menu) {
		case 1:
			searchProduct();
			break;
		case 2:
			searchCompany();
			break;	
		case 3:
			display();
			break;	
			
		default:
			System.exit(0);
			break;
		}
		
	}
	
	public void searchProduct() {
		System.out.println("---------물품명 검색-----------");
		System.out.println("검색할 상품명을 입력하세요.");
		System.out.print("상품명 : ");
		String product = scan.next();

		ArrayList<ProductDTO> list = new ProductDAO().searchProduct(product);
		System.out.println(product+"의 조회 결과");
		if ( list.size()!=0 ) {
			System.out.println("----------------------------검색 상품 리스트------------------------------");
			System.out.println("품번 \t 물품명 \t\t\t 제작회사 \t\t 가격 \t 수량");
			System.out.println("---------------------------------------------------------------------");
			
			for (ProductDTO dto : list) {
				System.out.printf("%d \t %-15s \t %-10s \t %d \t %d\n", dto.getNum(), dto.getProductName(), dto.getCompany(),dto.getPrice(),dto.getQty());
				System.out.println();
			}
			
			System.out.println("---------------------------------------------------------------------");
			
			// 메뉴
			
		}else {
			System.out.println("상품명을 확인하세요.\n\n");
			display();
		}
		
	}

	public void searchCompany() {
		System.out.println("---------회사 검색-----------");
		System.out.println("검색할 회사명을 입력하세요.");
		System.out.print("회사명 : ");
		String company = scan.next();

		ArrayList<ProductDTO> list = new ProductDAO().searchCompany(company);
		System.out.println(company+"의 조회결과");
		if ( list.size()!=0 ) {
			System.out.println("----------------------------검색 상품 리스트------------------------------");
			System.out.println("품번 \t 물품명 \t\t\t 제작회사 \t\t 가격 \t 수량");
			System.out.println("---------------------------------------------------------------------");
			
			for (ProductDTO dto : list) {
				System.out.printf("%d \t %-15s \t %-10s \t %d \t %d\n", dto.getNum(), dto.getProductName(), dto.getCompany(),dto.getPrice(),dto.getQty());
				System.out.println();
			}
			
			System.out.println("---------------------------------------------------------------------");
			
			// 메뉴
			
		}else {
			System.out.println("회사명을 확인하세요.\n\n");
			display();
		}

		
		
	}
	public void insertProduct() {
		System.out.println("---------상품 추가-----------");
		scan.nextLine();
		System.out.print("\n물품명 입력 : ");
		String productName = scan.nextLine();

		System.out.print("\n제작회사 입력 : ");
		String company = scan.nextLine();

		System.out.print("\n가격 입력 : ");
		int price = scan.nextInt();

		System.out.print("\n수량 입력 : ");
		int qty = scan.nextInt();

		int done = new ProductDAO().insertProduct(productName, company, price, qty);

		if (done == 1) {
			System.out.println(productName + "상품 추가 완료");
			}
		else
			System.out.println("상품 추가 실패 관리자에게 문의");
	}

	public void deleteProduct() {
		System.out.println("---------상품 삭제-----------");
		System.out.print("삭제할 물품 번호 : ");
		int num = scan.nextInt();

		int done = new ProductDAO().deleteProduct(num);
		if (done ==1) {
		System.out.println("삭제완료");
		list();
		}else {
			System.out.println("상품 삭제 실패 관리자에게 문의");
		}
	}

	public void updateProduct() {
		System.out.println("---------재고 관리-----------");
		System.out.println("1. 수량변경     2. 입고    3.출고    0. 이전");
		int select=scan.nextInt();
		int done =0;
		switch (select) {
		case 1:
			done = updateCargo();
			if(done ==1 ) {System.out.println("수량변경 성공!"); list();}
			else System.out.println("실패 관리자에게 문의하세요");
			break;

		case 2:
			done = getCargo();
			if(done ==1 ) {System.out.println("입고 성공!"); list();}
			else System.out.println("실패 관리자에게 문의하세요");
			break;
		case 3:
			done = releaseCargo();
			if(done ==1 ) {System.out.println("출고 성공!"); list();}
			else System.out.println("실패 관리자에게 문의하세요");
			break;
			
		default:
			break;
		}
	}
	public int updateCargo() {
		int done = 0;
		System.out.print("수량 변경할 물품 번호 : ");
		int num = scan.nextInt();
		System.out.print("변경할 수량 : ");
		int qty = scan.nextInt();
		done = new ProductDAO().updateProduct(num, qty);
		return done;

	}

	public int getCargo() {
		System.out.print("입고할 물품 번호 : ");
		int num = scan.nextInt();
		int done = 0;
		int remain = new ProductDAO().howMany(num);
		System.out.println("현재 재고 수량 : " + remain);
		System.out.print("입고할 수량 : ");
		int qty = scan.nextInt();

		if (qty <= 0) {
			System.out.println("수량은 0개 이상이어야 합니다.");
		} else {
			remain += qty;
			done = new ProductDAO().updateProduct(num, remain);
			return done;
		}
		return done;

	}

	public int releaseCargo() {
		System.out.print("출고할 물품 번호 : ");
		int num = scan.nextInt();
		int remain = new ProductDAO().howMany(num);
		int done = 0;
		System.out.println("현재 재고 수량 : " + remain);

		System.out.print("출고할 수량 : ");
		int qty = scan.nextInt();

		if (remain - qty < 0) {
			System.out.println("출고할 수량은 재고 수량을 초과할 수 없습니다.");
		} else {
			remain -= qty;
			done = new ProductDAO().updateProduct(num, remain);
			return done;
		}
		return done;
	}
	public void order(Scanner scan) {

		System.out.print("주문하실 상품의 번호 : ");
		int num = scan.nextInt();

		
		if (new ProductDAO().searchNum(num).getNum() == 0) {
			System.out.println("제품 번호를 확인해주세요.");
			order(scan);
		}
		if (new ProductDAO().searchNum(num).getQty() == 0) {
			System.out.println("해당 상품은 재고가 부족합니다.");
			order(scan);
		}

		System.out.print("주문하실 수량 : ");
		int qty = scan.nextInt();
		int errorCode = new ProductDAO().orderProduct(UserInfo.getUserinfo(), num, qty);
		if (qty <= 0) {
			System.out.println("수량은 최소 1개 이상 주문 하셔야합니다.");
			order(scan);
		}

		if (errorCode == 1) {
			System.out.println("주문이 완료되었습니다.");
			display();
		} else if (errorCode == -1) {
			System.out.println("잔액이 부족합니다.");
			display();
		} else {
			System.out.println("재고가 부족합니다.");
			display();
		}

	}
}
