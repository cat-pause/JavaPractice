package view;

import java.util.Scanner;

public class Index {
	Scanner scan;

	public Index(Scanner scan) {
		this.scan = scan;
	}

	public void display() {
		System.out.println("---------상품 관리 시스템-----------");
		System.out.println("1. 로그인   2. 회원가입  3. 비밀번호 찾기  0. 종료");
		System.out.print("메뉴 선택 : ");
		int menu = Integer.parseInt(scan.next());

		switch (menu) {
		case 1:
			View.mManage.login();
			;
			break;

		case 2:
			View.mManage.join();
			display();
			break;

		case 3:
			View.mManage.findPw();
			display();
			break;
		default:
			System.exit(0);
			break;
		}
		System.out.println("입력을 확인하세요");
		View.index.display();

	}
}
