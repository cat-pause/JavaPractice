package view;

public class View {
	static Index index;
	static ProductManage pManage;
	static MemberManage mManage;
}
